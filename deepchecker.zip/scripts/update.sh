#!/bin/bash

docker container stop $(docker container ls -aq)
docker system prune -af

docker-compose up -d

DEEPCHECKER_ID=$(docker ps -aqf "name=deepchecker$")

docker exec $DEEPCHECKER_ID composer install --no-cache --ignore-platform-reqs
docker exec $DEEPCHECKER_ID php artisan migrate --force