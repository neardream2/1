#!/bin/bash
docker exec -it deepchecker sh