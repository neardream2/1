#!/bin/bash

echo ""
echo ""
echo "  ___                ___ _           _           ";
echo " |   \ ___ ___ _ __ / __| |_  ___ __| |_____ _ _ ";
echo " | |) / -_) -_) '_ \ (__| ' \/ -_) _| / / -_) '_|";
echo " |___/\___\___| .__/\___|_||_\___\__|_\_\___|_|  ";
echo "              |_|                                ";
echo ""
echo ""

apt-get remove -y docker docker-engine docker.io containerd runc

apt-get update
apt-get install -y ca-certificates curl gnupg lsb-release software-properties-common

mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
curl -L "https://github.com/docker/compose/releases/download/v2.6.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

data_path="./data/certbot"
rsa_key_size=4096

if [ "$1" != "" ]; then
  cp docker/deepchecker/stubs/config/nginx-https.conf docker/deepchecker/config/nginx.conf
  sed -i "s/RESERVED_FOR_DOMAIN/$1/" docker/deepchecker/config/nginx.conf

  rm -Rf $data_path

  echo "Downloading recommended TLS parameters..."
  mkdir -p "$data_path/conf"
  curl -s https://raw.githubusercontent.com/certbot/certbot/master/certbot-nginx/certbot_nginx/_internal/tls_configs/options-ssl-nginx.conf > "$data_path/conf/options-ssl-nginx.conf"
  curl -s https://raw.githubusercontent.com/certbot/certbot/master/certbot/certbot/ssl-dhparams.pem > "$data_path/conf/ssl-dhparams.pem"
  echo

  echo "Creating dummy certificate for $1..."
  path="/etc/letsencrypt/live/$1"
  mkdir -p "$data_path/conf/live/$1"
  docker-compose run --rm --entrypoint "\
    openssl req -x509 -nodes -newkey rsa:$rsa_key_size -days 1\
      -keyout '$path/privkey.pem' \
      -out '$path/fullchain.pem' \
      -subj '/CN=localhost'" certbot
  echo
else
  cp docker/deepchecker/stubs/config/nginx.conf docker/deepchecker/config/nginx.conf
fi

docker-compose up -d

echo "Waiting containers initialization..."
sleep 30

DEEPCHECKER_ID=$(docker ps -aqf "name=deepchecker$")

#docker exec "$DEEPCHECKER_ID" composer install --no-cache
docker exec "$DEEPCHECKER_ID" php artisan package:discover
docker exec "$DEEPCHECKER_ID" php artisan migrate --force

if [ "$1" != "" ]; then
  echo "Deleting dummy certificate for $1..."

  docker-compose run --rm --entrypoint "\
    rm -Rf /etc/letsencrypt/live/$1 && \
    rm -Rf /etc/letsencrypt/archive/$1 && \
    rm -Rf /etc/letsencrypt/renewal/$1.conf" certbot
  echo

  docker-compose run --rm --entrypoint "\
    certbot certonly --webroot -w /var/www/certbot \
      -d $1 --register-unsafely-without-email \
      --rsa-key-size $rsa_key_size \
      --agree-tos \
      --force-renewal" certbot
  echo

  docker exec "$DEEPCHECKER_ID" nginx -s reload
fi