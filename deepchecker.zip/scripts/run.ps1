Write-Output ""
Write-Output ""
Write-Output "  ___                ___ _           _           ";
Write-Output " |   \ ___ ___ _ __ / __| |_  ___ __| |_____ _ _ ";
Write-Output " | |) / -_) -_) '_ \ (__| ' \/ -_) _| / / -_) '_|";
Write-Output " |___/\___\___| .__/\___|_||_\___\__|_\_\___|_|  ";
Write-Output "              |_|                                ";
Write-Output ""
Write-Output ""

& "$PSScriptRoot/remove.ps1"

$CurrentPath = (Get-Item .).FullName;

Copy-Item  "$CurrentPath\docker\deepchecker\stubs\config\nginx.conf" -Destination "$CurrentPath\docker\deepchecker\config\nginx.conf"

docker-compose up -d

Write-Output "Waiting containers initialization..."
Start-Sleep 30

$DeepcheckerId = @(docker ps -aqf "name=deepchecker$")

docker exec "$DeepcheckerId" php artisan package:discover
docker exec "$DeepcheckerId" php artisan migrate --force