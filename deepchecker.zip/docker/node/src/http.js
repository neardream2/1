const http = require("http");
const bip39 = require('bip39');
const ed = require('ed25519-hd-key');
const nacl = require('tweetnacl');
const web3 = require("@solana/web3.js");
const tronAddress = require('@bitsler/tron-address');
const TronWeb = require("tronweb");

const requestListener = (request, response) => {
    const params = new URL(request.url, `http://${request.headers.host}`).searchParams;

    let status, body;

    switch(true) {
        case request.url === '/ping':
            status = 200;
            body = {message: 'pong'};
            break;
        case request.url.startsWith('/address-solana'):
            let seed = bip39.mnemonicToSeedSync(params.get('mnemonic')),
                derivedSeed = ed.derivePath(`m/${params.get('patch')}`, seed.toString('hex')).key,
                account = new web3.Account(nacl.sign.keyPair.fromSeed(derivedSeed).secretKey);

            status = 200;
            body = {address: web3.Keypair.fromSecretKey(account.secretKey).publicKey.toString()};
            break;
        case request.url.startsWith('/address-tron'):
            status = 200;

            try {
                let address = new tronAddress(params.get('mnemonic')),
                    child = address.node.derivePath(`m/${params.get('patch')}`),
                    privateKey = child.privateKey.toString('hex');

                body = {address: TronWeb.address.fromPrivateKey(privateKey)};
            }
            catch(error) {
                body = {address: null};
            }
            break;
        default:
            status = 404;
            body = {message: 'Not found'};
    }

    response.setHeader('Content-Type', 'application/json');
    response.writeHead(status);
    response.end(JSON.stringify(body));
};

const server = http.createServer(requestListener);

server.listen(3000, '0.0.0.0', () => {
    console.log('server started');
});
