@if($has_updates)
    <div class="card">
        <!-- /.card-header -->
        <div class="card-body">
            Доступна новая версия <span class="badge badge-light">{{ $latest_version }}</span>. <a href="https://deepmng.com/download?key={{ env('APP_LICENSE_KEY') }}" target="_blank" class="text-reset">Скачайте обновление</a> и обновите скрипт до последней версии, используя инструкцию.
        </div>
        <!-- /.card-body -->
    </div>
@endif
