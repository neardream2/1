@if(!(new \App\Support\JsServer)->isAvailable())
    <div class="card">
        <!-- /.card-header -->
        <div class="card-body">
            Ошибка: локальный веб-сервер не найден. Работа с некоторыми валютами невозможна. Для устранения ошибки убедитесь, что вы полностью завершили <a href="https://github.com/deepchecker/guide/blob/main/INSTALL.md" target="_blank">установку</a>, иначе <a href="https://t.me/deepchecker_support" target="_blank">обратитесь в техподдержку</a>.
        </div>
        <!-- /.card-body -->
    </div>
@endif
