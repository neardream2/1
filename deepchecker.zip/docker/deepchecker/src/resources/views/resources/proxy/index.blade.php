@extends('layouts.app')

@section('buttons')
    <div class="btn-group" role="group">
        <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            Добавить
        </button>
        <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
            <a class="dropdown-item" href="{{ route('proxies.create') }}">Одно</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#storeMany">Несколько</a>
        </div>
    </div>
@endsection

@section('content')
    <div class="card card-default">
        <!-- form start -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Адрес</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                @foreach($proxies as $proxy)
                    <tr>
                        <td>{{ $proxy->name }}</td>
                        <td><code>{{ $proxy->toConnectionString() }}</code></td>
                        <td>
                            @if($proxy->is_active)
                                <span class="badge badge-success">Работает</span>
                            @else
                                <span class="badge badge-danger">Не работает</span>
                            @endif
                        </td>
                        <td>
                            <a href="{{ route('proxies.edit', $proxy) }}" class="btn btn-default btn-sm">Изменить</a>
                            <a href="{{ route('proxies.destroy', $proxy) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>

    {{ $proxies->links() }}
@endsection

@push('footer')
    <div class="modal fade" data-backdrop="static" id="storeMany" tabindex="-1" aria-labelledby="storeManyLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="storeManyLabel">Добавить несколько прокси</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="modal-body" method="post" action="{{ route('proxies.store_many') }}" data-action-form="store">
                    <div class="form-group">
                        <textarea class="form-control" name="proxies" rows="15" placeholder="http://user:password@127.0.0.1:465"></textarea>
                        <small class="text-muted">1 строка - 1 прокси. Формат - <code>тип://пользователь:пароль@ип:порт</code></small>
                    </div>
                </form>
                <div class="modal-footer">
                    <a href="#" class="btn btn-primary btn-block" data-action="store">Добавить</a>
                </div>
            </div>
        </div>
    </div>
@endpush
