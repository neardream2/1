@extends('layouts.app')

@section('buttons')
    <div class="btn-group" role="group">
        <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            Добавить
        </button>
        <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#createWallet">Списком</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#createWalletTxt">TXT-файлом</a>
        </div>
    </div>
    <div class="btn-group" role="group">
        <button id="btnGroupDrop2" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            Экспорт
        </button>
        <div class="dropdown-menu" aria-labelledby="btnGroupDrop2">
            <a class="dropdown-item" href="{{ route('export.mnemonics') }}">Seed-фразы</a>
            @foreach($currencyBuilder->allEnabled() as $currency)
                <a class="dropdown-item" href="{{ route('export.addresses', ['currency' => $currency->getSlug()]) }}">{{ $currency->getName() }} адреса</a>
            @endforeach
        </div>
    </div>
    <a href="{{ route('mnemonics.invalid') }}" class="btn btn-warning">Ошибки</a>
    {{--<a href="#" class="btn btn-danger" data-action="delete-page">Удалить текущую страницу</a>--}}
    <a href="#" class="btn btn-danger" data-action="truncate">Удалить все</a>
@endsection

@section('content')
    <form method="get" action="{{ route('index') }}" class="search-form mb-3">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <select class="form-control" name="direction">
                                <option selected disabled value="">Направление:</option>
                                @foreach($order_values['direction'] as $value)
                                    <option value="{{ $value }}" {{ $order['direction'] == $value ? 'selected' : '' }}>@lang("wallet.order.direction.{$value}")</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <select class="form-control" name="field">
                                <option selected disabled value="">Что сортируем:</option>
                                @foreach($order_values['fields'] as $value)
                                    <option value="{{ $value }}" {{ $order['field'] == $value ? 'selected' : '' }}>@lang("wallet.order.field.{$value}")</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group input-group-lg">
                        <input type="search" class="form-control form-control-lg" name="s" placeholder="Введите seed-фразу или адрес для поиска..." value="{{ $query }}">
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-lg btn-default">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="card">
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            @if($wallets->isNotEmpty())
                <table class="table table-hover text-nowrap">
                    <thead>
                    <tr>
                        <th style="width: 50%;">Адрес</th>
                        @can('view-any')
                            <th>Пользователь</th>
                        @endcan
                        <th>Дата изменения</th>
                        <th>Действия</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($wallets as $wallet)
                        <tr>
                            <td>
                                <code data-clipboard-value="{{ $wallet->mnemonic }}" data-toggle="tooltip" data-placement="right" title="Скопировать в буфер обмена">{!! $wallet->preview_mnemonic !!}</code>

                                @if($wallet->addresses)
                                    <ul class="nav nav-pills mt-3 mb-1" id="pills-tab-{{ $wallet->id }}" role="tablist">
                                        @php($i = 0)
                                        @foreach($wallet->addresses as $slug => $addresses)
                                            @php($currency = $currencyBuilder->get($slug))
                                            @continue(!$currency->isEnabled())
                                            <li class="nav-item">
                                                <a class="nav-link {{ $i++ === 0 ? 'active' : '' }}" id="pills-{{ $wallet->id }}-{{ $slug }}-tab" data-toggle="pill" href="#pills-{{ $wallet->id }}-{{ $slug }}" role="tab">
                                                    {{ $currency->getName() }}
                                                    @if(($total = $currency->getTotal($wallet->latest_result[$slug] ?? [])) > 0)
                                                        <span class="badge badge-info ml-1">${{ $total }}</span>
                                                    @endif
                                                </a>
                                            </li>
                                        @endforeach
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                        @php($i = 0)
                                        @foreach($wallet->addresses as $slug => $addresses)
                                            @php($currency = $currencyBuilder->get($slug))
                                            @continue(!$currency->isEnabled())
                                            <div class="tab-pane fade {{ $i++ === 0 ? 'show active' : '' }}" id="pills-{{ $wallet->id }}-{{ $slug }}" role="tabpanel">
                                                @foreach($addresses as $bip => $address)
                                                    <div>
                                                        <span class="badge bg-primary">m/{{ $bip }}</span>
                                                        <a href="{{ $currency->getLink($address) }}" target="_blank" class="badge bg-{{ isset($wallet->latest_result[$slug][$address]) ? 'primary' : ($wallet->latest_result ? 'danger' : 'secondary') }}">{{ $address }}</a>

                                                        @isset($wallet->latest_result[$slug][$address])
                                                            @if(is_array($wallet->latest_result[$slug][$address]))
                                                                @foreach($wallet->latest_result[$slug][$address] as $name => $value)
                                                                    <span class="badge bg-primary" data-toggle="tooltip" data-placement="top" title="{{ Str::title($name) }}">${{ $value }}</span>
                                                                @endforeach
                                                            @else
                                                                <span class="badge bg-primary" data-toggle="tooltip" data-placement="top" title="Баланс кошелька">${{ $wallet->latest_result[$slug][$address] }}</span>
                                                            @endif
                                                        @endisset
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            </td>
                            @can('view-any')
                                <td class="align-middle">
                                    <a href="{{ route('users.edit', $wallet->user) }}" class="text-reset">{{ $wallet->user->email }}</a>
                                </td>
                            @endcan
                            <td class="align-middle">
                                Последнее изменение - {{ $wallet->updated_at->diffForHumans() }}
                                @if($wallet->addresses)
                                    <br />Следующая проверка - {{ $wallet->next_check_at->format('d.m.Y H:i') }}
                                @endif
                            </td>
                            <td class="align-middle">
                                <form class="d-inline" method="post" action="{{ route('wallets.update', $wallet) }}" data-action-form="update-{{ $wallet->id }}">
                                    @method('put')

                                    <a href="#" class="btn btn-{{ $wallet->notifications_enabled ? 'success' : 'warning' }} btn-sm ml-1" data-action="update-{{ $wallet->id }}"  data-toggle="tooltip" data-placement="top" title="{{ $wallet->notifications_enabled ? 'Отключить уведомления' : 'Включить уведомления' }}">
                                        {!! $wallet->notifications_enabled ? '<i class="fas fa-bell"></i>' : '<i class="fas fa-bell-slash"></i>' !!}
                                    </a>
                                </form>
                                <a href="{{ route('wallets.destroy', $wallet) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy"  data-toggle="tooltip" data-placement="top" title="Удалить фразу">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @else
                <div class="alert alert-danger mb-0" role="alert">
                    <div class="text-center my-3">Seed-фразы не найдены</div>
                </div>
            @endif
        </div>
        <!-- /.card-body -->
    </div>

    {{ $wallets->onEachSide(1)->links() }}
@endsection

@push('footer')
    <div class="modal fade" data-backdrop="static" id="createWallet" tabindex="-1" aria-labelledby="createWalletLabel" aria-hidden="true" data-store-wallets-modal>
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createWalletLabel">Добавить Seed-фразы</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="modal-body" method="post" action="{{ route('wallets.store') }}">
                    <div class="row mb-3 wallets-progress d-none" data-route="{{ route('wallets.progress') }}">
                        <div class="col-md-12 mb-1 text-center wallets-status"></div>
                        <div class="col-md-12">
                            <div class="progress">
                                <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar" style="width: 100%"></div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="id" value="{{ Str::random() }}" />

                    <div class="form-group">
                        <textarea class="form-control" name="mnemonics" rows="15" placeholder="Seed-фразы..."></textarea>
                        <small class="text-muted">Возможно добавление нескольких Seed-фраз. 1 строка - 1 фраза. Внимание! Не рекомендуется добавлять большое (более 135000) количество seed-фраз за раз. Максимальное количество может отличаться в зависимости от мощности сервера.</small>
                    </div>
                    <div class="form-group">
                        <select class="form-control" name="locale">
                            @foreach($locales as $locale)
                                <option value="{{ $locale }}">{{ $locale }}</option>
                            @endforeach
                        </select>
                    </div>
                </form>
                <div class="modal-footer">
                    <a href="#" class="btn btn-primary btn-block"><span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span> Добавить</a>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" data-backdrop="static" id="createWalletTxt" tabindex="-1" aria-labelledby="createWalletTxtLabel" aria-hidden="true" data-store-wallets-modal>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createWalletLabel">Добавить Seed-фразы из TXT</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="modal-body" method="post" action="{{ route('wallets.store_txt') }}">
                    <div class="row mb-3 wallets-progress d-none" data-route="{{ route('wallets.progress') }}">
                        <div class="col-md-12 mb-1 text-center wallets-status"></div>
                        <div class="col-md-12">
                            <div class="progress">
                                <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar" style="width: 100%"></div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="id" value="{{ Str::random() }}" />

                    <div class="form-group">
                        <div class="custom-file mb-2">
                            <input type="file" class="custom-file-input" id="customFile" name="txt" accept="text/plain">
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
                        <small class="text-muted">1 строка - 1 фраза. Внимание! Не рекомендуется добавлять большое (более 135000) количество seed-фраз за раз. Максимальное количество может отличаться в зависимости от мощности сервера.</small>
                    </div>
                    <div class="form-group">
                        <select class="form-control" name="locale">
                            @foreach($locales as $locale)
                                <option value="{{ $locale }}">{{ $locale }}</option>
                            @endforeach
                        </select>
                    </div>
                </form>
                <div class="modal-footer">
                    <a href="#" class="btn btn-primary btn-block"><span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span> Добавить</a>
                </div>
            </div>
        </div>
    </div>

    <form method="post" action="{{ route('wallets.delete_page', $wallets->currentPage()) }}" data-action-form="delete-page">@method('delete')</form>
    <form method="post" action="{{ route('wallets.truncate') }}" data-action-form="truncate">@method('delete')</form>
@endpush
