@extends('layouts.app')

@section('buttons')
    <a href="{{ route('users.create') }}" class="btn btn-primary">Добавить пользователя</a>
@endsection

@section('content')
    <div class="card card-default">
        <!-- form start -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Группа</th>
                    <th>Seed-фраз</th>
                    <th>Создан</th>
                    <th>Изменен</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                @foreach($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->email }}</td>
                        <td>@lang("user.group.{$user->group}")</td>
                        <td>{{ $user->wallets_count }}</td>
                        <td>{{ $user->created_at->format('d.m.Y H:i') }}</td>
                        <td>{{ $user->updated_at->diffForHumans() }}</td>
                        <td>
                            <a href="{{ route('users.edit', $user) }}" class="btn btn-default btn-sm">Изменить</a>
                            <a href="{{ route('users.destroy', $user) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>

    {{ $users->links() }}
@endsection
