@extends('layouts.app')

@section('buttons')
    <a href="#" class="btn btn-primary" data-action="store">Добавить</a>
@endsection

@section('content')
    <form action="{{ route('users.store') }}" method="post" data-action-form="store">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Контактные данные</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email">
                </div>

                <div class="form-group">
                    <label>Группа</label>
                    <select class="form-control" name="group">
                        @foreach($groups as $group)
                            <option value="{{ $group }}">@lang("user.group.{$group}")</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Telegram</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>Частота проверки</label>
                    <select class="form-control" name="check_period">
                        @foreach($periods as $period)
                            <option value="{{ $period }}">@lang("wallet.period.{$period}")</option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label>Уведомлять, если баланс кошелька превысит</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">$</span>
                        </div>
                        <input type="number" class="form-control" name="notify_minimal_amount">
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Безопасность</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label>Пароль</label>
                        <input type="password" class="form-control" name="password" autocomplete="new-password">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>Пароль еще раз</label>
                        <input type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </form>
@endsection
