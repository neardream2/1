<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $navigation->title() }}</title>
    <link rel="stylesheet" href="{{ mix('css/app.css') }}">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    {{--<div class="preloader flex-column justify-content-center align-items-center">
        DeepChecker
    </div>--}}

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>

            @can('view-any')
                <li class="nav-item d-none d-sm-inline-block">
                    <span class="nav-link">Всего: {{ $wallets_count }}</span>
                </li>
            @endcan

            <li class="nav-item">
                <span class="nav-link">В очереди: {{ $wallets_awaiting_count }}</span>
            </li>

            @can('view-any')
                <li class="nav-item d-none d-sm-inline-block">
                    <span class="nav-link">До окончания: ~{{ $statistic->get() }} мин</span>
                </li>
            @endcan
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto d-none d-lg-block">
            <!-- Notifications Dropdown Menu -->
            @hasSection('buttons')
                <div class="col-sm-12">
                    <div class="float-sm-right mt-3 mt-sm-0">
                        @yield('buttons')
                    </div>
                </div><!-- /.col -->
            @endif
        </ul>
    </nav>
    <!-- /.navbar -->

    @hasSection('buttons')
        <div class="mobile-buttons d-block d-lg-none py-2 position-fixed w-100 text-center">
            @yield('buttons')
        </div>
    @endif

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="/" class="brand-link">
            {{--<img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">--}}
            <span class="brand-text font-weight-light ml-3">{{ config('app.name') }}</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar flex-wrapper-item">
            <!-- Sidebar Menu -->
            <nav class="mt-2 flex-top">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    @foreach($navigation->menu() as $item)
                        <li class="nav-item">
                            <a href="{{ $item->route }}" class="nav-link {{ $item->active ? 'active' : '' }}">
                                <i class="nav-icon {{ $item->icon }}"></i>
                                <p>{{ $item->name }}</p>
                                @if($item->badge !== null)
                                    <span class="badge badge-primary right">{{ $item->badge }}</span>
                                @endif
                            </a>
                        </li>
                    @endforeach
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                @can('view-any')
                    @include('particles.version')
                    @include('particles.js-server-checker')
                @endcan

                @yield('content')

                {{--@hasSection('buttons')
                    <div class="card card-default">
                        <!-- form start -->
                        <div class="card-body text-left text-md-right">
                            @yield('buttons')
                        </div>
                        <!-- /.card-body -->
                    </div>
                @endif--}}
            </div><!-- /.container-fluid -->
        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <strong>Copyright &copy; {{ now()->year }} <a href="{{ config('app.url') }}" class="text-black-50">{{ config('app.name') }}</a>.</strong>
        <div class="float-right d-none d-sm-inline-block">
            {{ File::get(base_path('version.txt')) }}
        </div>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<form class="d-none" method="post" data-action-form="destroy">@method('delete')</form>

@stack('footer')
<script src="{{ mix('js/app.js') }}"></script>
</body>
</html>
