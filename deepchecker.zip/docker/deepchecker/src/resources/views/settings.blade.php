@extends('layouts.app')

@section('buttons')
    <a href="#" class="btn btn-primary" data-action="update">Обновить</a>
    @can('view-any')
        <a href="#" class="btn btn-warning" data-action="set-webhook">Привязать вебхук Telegram</a>
        <a href="#" class="btn btn-warning" data-action="reload">Перезапустить очереди</a>
    @endcan
@endsection

@section('content')
    <form class="settingsForm" action="{{ route('settings.update') }}" method="post" data-action-form="update">
        @method('put')

        @can('view-any')
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Лицензия</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <p>Лицензия активна до <span class="badge badge-light">{{ $license_date->format('d.m.Y H:i') }}</span>. Обратитесь в телеграм <a href="https://t.me/deepchecker_support" target="_blank" class="text-reset text-bold">@deepchecker_support</a> для продления лицензии.</p>
                </div>
                <!-- /.card-body -->
            </div>
        @endcan

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Контактные данные</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" value="{{ $user->email }}">
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Безопасность</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label>Пароль</label>
                        <input type="password" class="form-control" name="password" autocomplete="new-password">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>Пароль еще раз</label>
                        <input type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Настройки кошельков</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>Частота проверки</label>
                    <select class="form-control" name="check_period">
                        @foreach($periods as $period)
                            <option value="{{ $period }}" {{ $period == $user->check_period ? 'selected' : '' }}>@lang("wallet.period.{$period}")</option>
                        @endforeach
                    </select>
                </div>

                @if(config('autoload.telegram_bot_name'))
                    <div class="form-group">
                        <label>Уведомлять, если баланс кошелька превысит</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="number" class="form-control" name="notify_minimal_amount" value="{{ $user->notify_minimal_amount }}">
                        </div>
                    </div>

                    @if($user->telegrams->count() < 20)
                        <p>Для привязки Telegram к профилю скопируйте сообщение ниже и отправьте его боту <a href="https://t.me/{{ config('autoload.telegram_bot_name') }}" target="_blank" class="font-weight-bold">{{ '@'.config('autoload.telegram_bot_name') }}</a>.</p>

                        <div class="form-group">
                            <input type="text" class="form-control" value="/pair {{ $user->telegramCode->code }}" readonly data-clipboard-value="/pair {{ $user->telegramCode->code }}" data-toggle="tooltip" data-placement="bottom" title="Скопировать в буфер обмена" />
                        </div>
                    @endif
                @endif
            </div>
            <!-- /.card-body -->
        </div>

        @if($user->telegrams->isNotEmpty())
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Чаты Telegram</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <table class="table table-hover text-nowrap">
                        <thead>
                        <tr>
                            <th style="width: 70%;">Название</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($user->telegrams as $telegram)
                            <tr>
                                <td class="align-middle">{{ $telegram->name }}</td>
                                <td class="align-middle">
                                    <a href="{{ route('settings.detach_telegram', $telegram) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy" data-toggle="tooltip" data-placement="top" title="Отвязать аккаунт">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        @endif

        @can('view-any')
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Настройки валют</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <ul class="nav nav-pills" id="pills-tab-currencies" role="tablist">
                        @foreach($currencies as $currency)
                            <li class="nav-item">
                                <a class="nav-link {{ $loop->first ? 'active' : '' }}" id="pills-{{ $currency->getSlug() }}-tab" data-toggle="pill" href="#pills-{{ $currency->getSlug() }}" role="tab">
                                    {{ $currency->getName() }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        @foreach($currencies as $currency)
                            <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }} mt-3" id="pills-{{ $currency->getSlug() }}" role="tabpanel">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" name="currencies[{{ $currency->getSlug() }}][is_enabled]" id="currencyEnabled{{ $currency->getSlug() }}" {{ $currency->isEnabled() ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="currencyEnabled{{ $currency->getSlug() }}">Валюта включена</label>
                                </div>

                                <div class="form-group mt-3">
                                    <label class="d-block">Доступные патчи</label>
                                    <select class="form-control d-block" name="currencies[{{ $currency->getSlug() }}][patches][]" multiple>
                                        @foreach($currency->getPatches() as $value => $name)
                                            <option value="{{ $value }}" {{ $currency->isEnabledPatch($value) ? 'selected' : '' }}>{{ $name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <!-- /.card-body -->
            </div>

            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Telegram</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Имя бота</label>
                            <input type="text" class="form-control" name="telegram_bot_name" value="{{ config('autoload.telegram_bot_name') }}">
                        </div>

                        <div class="col-md-6 form-group">
                            <label>Токен</label>
                            <input type="text" class="form-control" name="telegram_api_key" value="{{ config('autoload.telegram_api_key') }}">
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>

            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Blockchair</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <p>Часть валют (Bitcoin, BitcoinCash) взаимодействуют с <a href="https://blockchair.com/api" target="_blank" class="link-black">blockchair.com</a> для получения данных о кошельках. Данное API ограничивает максимальное количество запросов в день. Если вы сталкиваетесь с большим количеством «красных» адресов - рекомендую <a href="https://blockchair.com/api/plans" target="_blank" class="link-black">увеличить ежедневный лимит</a>.</p>

                    <div class="form-group">
                        <label>API-ключ</label>
                        <input type="text" class="form-control" name="blockchair_api_key" value="{{ config('autoload.blockchair_api_key') }}">
                    </div>
                </div>
                <!-- /.card-body -->
            </div>

            <div class="card card-default">
                <div class="card-body">
                    {!! Str::markdown($update) !!}
                </div>
                <!-- /.card-body -->
            </div>
        @endcan
    </form>
@endsection

@push('footer')
    @can('view-any')
        <form method="get" action="{{ route('settings.telegram') }}" data-action-form="set-webhook"></form>
        <form method="get" action="{{ route('settings.queues') }}" data-action-form="queues"></form>
        <form method="get" action="{{ route('settings.reload') }}" data-action-form="reload"></form>
    @endcan
@endpush
