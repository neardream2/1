<?php

use App\Support\StoreWalletsProgress;

return [
    'period' => [
        180 => '3 часа',
        360 => '6 часов',
        999999 => 'Выключить повторную проверку'
    ],

    'order' => [
        'direction' => [
            'asc' => 'По возрастанию',
            'desc' => 'По убыванию'
        ],

        'field' => [
            'total' => 'Баланс',
            'created_at' => 'Дате создания',
        ]
    ],

    'progress' => [
        'status' => [
            StoreWalletsProgress::STATUS_PREPARING => 'Подготовка seed-фраз: :current из :total',
            StoreWalletsProgress::STATUS_CREATING => 'Добавление seed-фраз: :current из :total',
            StoreWalletsProgress::STATUS_READY => 'Seed-фразы успешно добавлены'
        ]
    ]
];
