<?php

use App\Models\User;

return [
    'group' => [
        User::GROUP_ADMIN => 'Администратор',
        User::GROUP_USER => 'Пользователь'
    ]
];
