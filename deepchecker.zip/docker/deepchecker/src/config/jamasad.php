<?php

return [
    'currencies' => [
        \App\Support\Currency\Bitcoin::class,
        \App\Support\Currency\BitcoinCash::class,
        \App\Support\Currency\Dogecoin::class,
        \App\Support\Currency\Ethereum::class,
        \App\Support\Currency\Litecoin::class,
        \App\Support\Currency\Solana::class,
        \App\Support\Currency\Tron::class
    ]
];
