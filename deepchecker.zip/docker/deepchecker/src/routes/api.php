<?php

use App\Http\Controllers\Api\TelegramWebhookController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('telegram/vDC79MRfbJ352shSI8jM', [TelegramWebhookController::class, 'get'])->name('api.telegram.get');
//Route::get('telegram/vDC79MRfbJ352shSI8jM', [TelegramWebhookController::class, 'set'])->name('api.telegram.set');
