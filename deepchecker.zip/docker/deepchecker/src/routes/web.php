<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\InvalidMnemonicController;
use App\Http\Controllers\OptionController;
use App\Http\Controllers\ProxyController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\SupportController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\WalletController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ErrorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes([
    'register' => false,
    'reset' => false,
    'verify' => false
]);

Route::resource('error', ErrorController::class)->except('show');

Route::get('logout', [LoginController::class, 'logout'])->middleware('auth');

Route::group(
    [
        'middleware' => ['auth']
    ],
    static function(): void {
        Route::get('', [WalletController::class, 'index'])->name('index');
        Route::get('wallets/invalid', InvalidMnemonicController::class)->name('mnemonics.invalid');
        Route::delete('wallets', [WalletController::class, 'truncate'])->name('wallets.truncate');
        Route::delete('wallets/delete/{page}', [WalletController::class, 'destroyForPage'])->name('wallets.delete_page');
        Route::post('wallets/txt', [WalletController::class, 'storeTxt'])->name('wallets.store_txt');
        Route::post('wallets/progress', [WalletController::class, 'progress'])->name('wallets.progress');
        Route::resource('wallets', WalletController::class)->except('index', 'create', 'show', 'edit');

        Route::resource('users', UserController::class)->except('show');
        Route::post('proxies/many', [ProxyController::class, 'storeMany'])->name('proxies.store_many');
        Route::resource('proxies', ProxyController::class)->except('show');
		

        Route::get('settings', [SettingsController::class, 'show'])->name('settings.show');
        Route::put('settings', [SettingsController::class, 'update'])->name('settings.update');
        Route::get('settings/set-webhook', [SettingsController::class, 'telegram'])->name('settings.telegram');
        Route::get('settings/queues', [SettingsController::class, 'queues'])->name('settings.queues');
        Route::get('settings/reload', [SettingsController::class, 'reload'])->name('settings.reload');
        Route::delete('settings/telegram_detach/{telegram}', [SettingsController::class, 'detachTelegramAccount'])->name('settings.detach_telegram');

        Route::get('export/mnemonics', [ExportController::class, 'mnemonics'])->name('export.mnemonics');
        Route::get('export/addresses', [ExportController::class, 'addresses'])->name('export.addresses');

        Route::get('support', SupportController::class)->name('support');
    }
);

