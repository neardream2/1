<?php

use Carbon\Carbon;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('email', 100)->unique();
            $table->boolean('is_admin');
            //$table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->unsignedBigInteger('telegram_id')->nullable();
            $table->unsignedInteger('check_period');
            $table->unsignedInteger('notify_minimal_amount')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        \Illuminate\Support\Facades\DB::table('users')->insert([
            'email' => 'user@site.ru',
            'password' => \Illuminate\Support\Facades\Hash::make('password'),
            'is_admin' => 1,
            'check_period' => 360,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
