<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWalletsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wallets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->index()->references('id')->on('users')->cascadeOnDelete();
            $table->string('mnemonic', 512)->index();
            $table->json('addresses')->nullable();
            $table->json('latest_result')->nullable();
            $table->json('previously_result')->nullable();
            $table->timestamp('next_check_at')->nullable();
            $table->boolean('notifications_enabled');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wallets');
    }
}
