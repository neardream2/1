<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateUsersTableAddGroupColumn extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function(Blueprint $table) {
            $table->unsignedTinyInteger('group')->after('is_admin');
        });

        \Illuminate\Support\Facades\DB::table('users')->where('is_admin', 1)->update(['group' => 1]);
        \Illuminate\Support\Facades\DB::table('users')->where('is_admin', 0)->update(['group' => 9]);

        Schema::table('users', function(Blueprint $table) {
            $table->dropColumn('is_admin');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
