<?php

namespace App\Console\Commands;

use App\Models\InvalidMnemonic;
use Carbon\Carbon;
use Illuminate\Console\Command;

/**
 * Class WalletClear
 */
class WalletClear extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wallet:clear';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        InvalidMnemonic::where('created_at', '<', Carbon::now()->subDay())->delete();
    }
}
