<?php

namespace App\Console\Commands;

use App\Models\Wallet;
use App\Support\Mnemonic;
use App\Support\Statistic;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

/**
 * Class WalletAddresses
 */
class WalletAddresses extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wallet:addresses {queue*} {--loop}';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        if($this->option('loop')) {
            while(true) {
                if($this->isRestartRequired()) {
                    $this->restartPlanned();
                    $this->info('Перезапуск очереди...');
                    break;
                }

                sleep(
                    $this->exec()
                );
            }
        }
        else {
            $this->exec();
        }
    }

    /**
     * @return int
     */
    public function exec(): int
    {
        $wallet = Wallet::whereNull('addresses')->whereIn('queue_id', $this->argument('queue'))->first()
                    ?? Wallet::whereNull('addresses')->whereNotIn('queue_id', $this->argument('queue'))->inRandomOrder()->first();;

        if(!$wallet) {
            return 5;
        }

        $lock = Cache::lock('wallet.'.$wallet->id, 45);

        if($lock->get()) {
            $startTime = microtime(true);

            $mnemonic = new Mnemonic($wallet->mnemonic);

            $wallet->addresses = $mnemonic->getAllAddresses();
            $wallet->save();

            (new Statistic)->put(Statistic::ADDRESSES_KEY, microtime(true) - $startTime);

            $lock->release();
        }

        return 1;

        /*$statistic = new Statistic;
        $execTimes = [];

        Wallet::whereNull('addresses')
            ->whereIn('queue_id', $this->argument('queue'))->limit(100)->get()
            ->each(static function(Wallet $wallet) use(&$execTimes): void {
                $startTime = microtime(true);

                $mnemonic = new Mnemonic($wallet->mnemonic);

                $wallet->addresses = $mnemonic->getAllAddresses();
                $wallet->save();

                $execTimes[$wallet->queue_id] ??= [];
                $execTimes[$wallet->queue_id][] = microtime(true) - $startTime;
            });

        foreach($execTimes as $queue => $values) {
            $statistic->put($queue, $values, Statistic::ADDRESSES_PREFIX);
        }*/
    }

    /**
     * @return bool
     */
    protected function isRestartRequired(): bool
    {
        foreach($this->argument('queue') as $queue) {
            if(Cache::has("restart_{$queue}_addresses")) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return void
     */
    protected function restartPlanned(): void
    {
        foreach($this->argument('queue') as $queue) {
            Cache::forget("restart_{$queue}_addresses");
        }
    }
}
