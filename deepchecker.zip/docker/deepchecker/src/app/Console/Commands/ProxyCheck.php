<?php

namespace App\Console\Commands;

use App\Models\Proxy as Model;
use App\Support\Proxy;
use Illuminate\Console\Command;

/**
 * Class ProxyCheck
 */
class ProxyCheck extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'proxy:check';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        $helper = new Proxy;
        $needResetCache = false;

        Model::get()
            ->each(static function(Model $proxy) use ($helper, &$needResetCache): void {
                $proxy->is_active = 1;

                if(!$helper->valid($proxy->toConnectionString())) {
                    $this->info('Proxy '.$proxy->toConnectionString().' not active.');
                    $needResetCache = true;
                    $proxy->is_active = 0;
                }

                $proxy->save();
            });

        $needResetCache && $helper->reset();
    }
}