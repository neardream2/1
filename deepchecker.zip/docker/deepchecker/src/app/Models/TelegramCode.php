<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * Class TelegramCode
 * @property int $id
 * @property int $user_id
 * @property string $code
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class TelegramCode extends Model
{
    protected $fillable = [
        'user_id', 'code'
    ];

    /**
     * @return void
     */
    protected static function boot(): void
    {
        parent::boot();
        static::creating(static fn(TelegramCode $telegramCode) => $telegramCode->generateNewCode());
    }

    /**
     * @return void
     */
    public function generateNewCode(): void
    {
        while(true) {
            $randString = Str::random(32);

            if(!static::where('code', $randString)->exists()) {
                $this->code = $randString;
                break;
            }
        }
    }
}