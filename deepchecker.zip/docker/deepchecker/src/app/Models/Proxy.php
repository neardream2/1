<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Proxy
 * @property int $id
 * @property bool $is_active
 * @property string $name
 * @property int $type
 * @property string $ip
 * @property int $port
 * @property string $user
 * @property string $password
 */
class Proxy extends Model
{
    public const TYPE_SOCKS5 = 1;
    public const TYPE_HTTPS = 2;

    public $timestamps = false;

    protected $fillable = [
        'is_active', 'name', 'type', 'ip', 'port', 'user', 'password'
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'type' => 'integer'
    ];

    protected $attributes = [
        'is_active' => 1
    ];

    /**
     * @return string
     */
    public function toConnectionString(): string
    {
        $protocol = match($this->type) {
            self::TYPE_SOCKS5 => 'socks5',
            self::TYPE_HTTPS => 'http',
            default => 'tcp'
        };

        return $this->user
            ? sprintf('%s://%s:%s@%s:%s', $protocol, $this->user, $this->password, $this->ip, $this->port)
            : sprintf('%s://%s:%s', $protocol, $this->ip, $this->port);
    }

    /**
     * @param string $protocol
     * @return int
     * @throws Exception
     */
    public static function getProtocolValue(string $protocol): int
    {
        return match($protocol) {
            'socks5' => self::TYPE_SOCKS5,
            'http' => self::TYPE_HTTPS,
            default => throw new Exception('Protocol not found.')
        };
    }

    /**
     * @return array
     */
    public static function types(): array
    {
        return [
            self::TYPE_SOCKS5, self::TYPE_HTTPS
        ];
    }
}
