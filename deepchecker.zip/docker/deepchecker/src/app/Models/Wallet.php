<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

/**
 * Class Model
 * @property int $id
 * @property int $user_id
 * @property string $mnemonic
 * @property array $addresses
 * @property int $queue_id
 * @property array $latest_result
 * @property array $previously_result
 * @property Carbon $next_check_at
 * @property bool $notifications_enabled
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property User $user
 *
 * @method static $this|Builder whereIsNeedCheck()
 */
class Wallet extends Model
{
    public const MIN_QUEUE_ID = 1;
    public const MAX_QUEUE_ID = 10;

    protected $fillable = [
        'user_id', 'mnemonic', 'addresses', 'queue_id',
        'latest_result', 'previously_result', 'next_check_at'
    ];

    protected $casts = [
        'addresses' => 'array',
        'latest_result' => 'array',
        'previously_result' => 'array',
        'next_check_at' => 'datetime',
        'notifications_enabled' => 'boolean'
    ];

    protected $attributes = [
        'notifications_enabled' => 1
    ];

    /**
     * @return void
     */
    protected static function boot(): void
    {
        parent::boot();
        static::creating(static function(Wallet $wallet): void {
            $wallet->queue_id = static::orderByDesc('id')->first()->queue_id ?? self::MIN_QUEUE_ID;
            $wallet->queue_id = $wallet->queue_id >= self::MAX_QUEUE_ID ? self::MIN_QUEUE_ID : $wallet->queue_id + 1;
        });
    }

    /**
     * @return BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return string
     */
    public function getPreviewMnemonicAttribute(): string
    {
        $result = [];
        $line = $length = 0;

        foreach(explode(' ', $this->mnemonic) as $word) {
            $result[$line] ??= [];
            $result[$line][] = $word;
            $length += Str::length($word);

            if($length >= 40) {
                $line++;
                $length = 0;
            }
        }


        return implode(
            '<br />',
            array_map(static fn(array $words): string => e(implode(' ', $words)), $result)
        );
    }

    /**
     * @param Builder $builder
     * @return void
     */
    public function scopeWhereIsNeedCheck(Builder $builder): void
    {
        $builder
            ->where('next_check_at', '<', Carbon::now())
            ->whereNotNull('addresses');
    }
}