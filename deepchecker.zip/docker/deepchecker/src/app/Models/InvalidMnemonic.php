<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class InvalidMnemonic
 * @property int $id
 * @property string $mnemonic
 * @property array $invalid_words
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class InvalidMnemonic extends Model
{
    protected $fillable = [
        'mnemonic', 'invalid_words'
    ];

    protected $casts = [
        'invalid_words' => 'array'
    ];

    /**
     * @return string
     */
    public function getFormattedString(): string
    {
        $result = [];

        foreach(explode(' ', $this->mnemonic) as $word) {
            $result[] = in_array($word, $this->invalid_words) ? '<span class="text-danger text-bold">'.e($word).'</span>' : e($word);
        }

        return implode(' ', $result);
    }
}