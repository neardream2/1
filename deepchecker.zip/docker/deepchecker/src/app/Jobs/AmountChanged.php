<?php

namespace App\Jobs;

use App\Models\User;
use App\Models\UserTelegram;
use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use App\Support\TelegramBot\Loader;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\App;
use Longman\TelegramBot\Exception\TelegramException;

class AmountChanged implements ShouldQueue
{
    use Dispatchable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(
        protected Wallet $wallet
    ) {}

    /**
     * @return void
     * @throws TelegramException
     */
    public function handle(): void
    {
        try {
            /** @var Loader $telegramLoader */
            $telegramLoader = App::make(Loader::class);
        }
        catch(TelegramException) {
            return;
        }

        if(!$telegramLoader->isEnabledFeature()) {
            return;
        }

        $currencyBuilder = new CurrencyBuilder;

        $users = $telegramLoader->sendCopyTo();

        if($this->wallet->notifications_enabled && !$users->contains($this->wallet->user) && $this->wallet->user->telegrams->isNotEmpty()) {
            $users->add($this->wallet->user);
        }

        if(!$this->wallet->notifications_enabled && $this->wallet->user->is_admin) {
            $userKey = $users->search(fn(User $user): bool => $user->id == $this->wallet->user_id);
            $userKey !== false && $users->forget($userKey);
        }

        $users->each(function(User $user) use ($telegramLoader, $currencyBuilder): void {
            if(!$this->wallet->latest_result || !$user->notify_minimal_amount || $user->telegrams->isEmpty()) {
                return;
            }

            $data = $currencyBuilder->getChangedValues($this->wallet->latest_result, $user->notify_minimal_amount);

            if(!$data) {
                return;
            }

            $message = "<strong>{$this->wallet->mnemonic}</strong>\n";

            foreach($data as $currency => $addresses) {
                $message .= "\n<strong>{$currency}:</strong>\n";

                foreach($addresses as $address => $balance) {
                    $message .= "<code>{$address}</code>: \${$balance}\n";
                }
            }

            $user->telegrams->each(static function(UserTelegram $telegram) use ($telegramLoader, $message): void {
                $telegramLoader->makeRequest('sendMessage', [
                    'text' => $message,
                    'parse_mode' => 'HTML',
                    'chat_id' => $telegram->chat_id
                ]);
            });
        });
    }
}
