<?php

namespace App\Http\ViewComposers;
use App\Support\Statistic;
use Illuminate\View\View;

/**
 * Class StatisticComposer
 */
class StatisticComposer
{
    /**
     * @param Statistic $statistic
     */
    public function __construct(
        protected Statistic $statistic
    ) {}

    /**
     * Bind data to the view.
     *
     * @param View $view
     * @return void
     */
    public function compose(View $view): void
    {
        //dd($this->statistic->get());

        $view->with('statistic', $this->statistic);
    }
}