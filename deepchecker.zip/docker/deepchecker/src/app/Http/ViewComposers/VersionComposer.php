<?php

namespace App\Http\ViewComposers;

use Carbon\Carbon;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\View\View;

/**
 * Class VersionComposer
 */
class VersionComposer
{
    /**
     * @param View $view
     * @return void
     * @throws FileNotFoundException
     */
    public function compose(View $view): void
    {
        $view
            ->with('latest_version', $this->latestVersion())
            ->with('has_updates', $this->hasUpdates());
    }

    /**
     * @return string
     */
    protected function latestVersion(): string
    {
        return Cache::remember(
            'latest_version', Carbon::now()->addHour(),
            static function(): string {
                return Http::get('https://deepmng.com/api/ping')->throw()->json('version');
            }
        );
    }

    /**
     * @return bool
     * @throws FileNotFoundException
     */
    protected function hasUpdates(): bool
    {
        return version_compare($this->latestVersion(), File::get(base_path('version.txt')), '>');
    }
}
