<?php

namespace App\Http\ViewComposers;

use App\Support\Navigation;
use Illuminate\View\View;

/**
 * Class NavigationComposer
 */
class NavigationComposer
{
    /**
     * @param Navigation $navigation
     */
    public function __construct(
        protected Navigation $navigation
    ) {}

    /**
     * Bind data to the view.
     *
     * @param View $view
     * @return void
     */
    public function compose(View $view): void
    {
        $view->with('navigation', $this->navigation);
    }
}