<?php

namespace App\Http\ViewComposers;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\View\View;

/**
 * Class WalletsCountComposer
 */
class WalletsCountComposer
{
    /**
     * @param Request $request
     */
    public function __construct(
        protected Request $request
    ) {}

    /**
     * Bind data to the view.
     *
     * @param View $view
     * @return void
     */
    public function compose(View $view): void
    {
        $view
            ->with('wallets_count', $this->walletsCount())
            ->with('wallets_awaiting_count', $this->awaitingWalletsCount());
    }

    /**
     * @return int
     */
    public function walletsCount(): int
    {
        return Cache::remember(
            'wallets_count', Carbon::now()->addHour(),
            static fn(): int => Wallet::count()
        );
    }

    /**
     * @return int
     */
    public function awaitingWalletsCount(): int
    {
        return Cache::remember(
            'wallets_awaiting_count', Carbon::now()->addMinute(),
            static fn(): int => Wallet::whereNull('addresses')->orWhere(static fn(Builder $builder) => $builder->whereIsNeedCheck())->count()
        );
    }
}
