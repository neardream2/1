<?php

namespace App\Http\Requests;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Class UpdateSettingsRequest
 */
class UpdateSettingsRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules = [
            // User attributes
            'email' => ['required', 'email', 'max:100', Rule::unique('users')->whereNot('id', $this->user()->id)],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
            'check_period' => ['required', 'integer', Rule::in(User::periods())],
            'notify_minimal_amount' => ['nullable', 'integer', 'min:1', 'max:4294966322']
        ];

        if($this->user()->can('view-any')) {
            $rules = array_merge($rules, [
                // App settings
                'telegram_bot_name' => ['required_with:telegram_api_key', 'nullable', 'string'],
                'telegram_api_key' => ['required_with:telegram_bot_name', 'nullable', 'string'],
                'currencies' => ['required', 'array'],
                'currencies.*.patches' => ['nullable', 'array'],
                'blockchair_api_key' => ['nullable', 'string']
            ]);
        }

        return $rules;
    }
}
