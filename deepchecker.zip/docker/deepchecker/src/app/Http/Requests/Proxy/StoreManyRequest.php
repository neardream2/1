<?php

namespace App\Http\Requests\Proxy;

use App\Models\Proxy;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Class StoreManyRequest
 */
class StoreManyRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'proxies' => ['required', 'string']
        ];
    }
}
