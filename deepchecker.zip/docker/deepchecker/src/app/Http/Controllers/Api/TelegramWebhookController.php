<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Support\JsonResponse;
use App\Support\TelegramBot\Loader;
use Exception;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;
use Longman\TelegramBot\Exception\TelegramException;

/**
 * Class TelegramWebhookController
 * @package App\Http\Controllers\Api
 */
class TelegramWebhookController extends Controller
{
    protected Loader $loader;

    /**
     * TelegramWebhookController constructor.
     * @param Loader $loader
     */
    public function __construct(Loader $loader)
    {
        $this->loader = $loader;
    }

    /**
     * @return void
     */
    public function get(): void
    {
        try {
            $this->loader->appendCommands();
            $this->loader->handle();
        }
        catch(TelegramException $e) {
            Log::error($e->getMessage());
        }
    }

    /**
     * @return JsonResponse
     */
    public function set(): JsonResponse
    {
        if(App::isProduction()) {
            abort(404);
        }

        try {
            $this->loader->deleteWebhook();

            $result = $this->loader->setWebhook(
                route('api.telegram.get')
            );

            return $result->isOk() ? JsonResponse::success($result->getDescription()) : JsonResponse::error($result->getDescription());
        }
        catch(Exception $e) {
            return JsonResponse::error($e->getMessage());
        }
    }
}
