<?php

namespace App\Http\Controllers;

use App\Http\Requests\Proxy\StoreManyRequest;
use App\Http\Requests\Proxy\StoreRequest;
use App\Http\Requests\Proxy\UpdateRequest;
use App\Models\Proxy;
use App\Support\JsonResponse;
use App\Support\Navigation;
use App\Support\Proxy as ProxyHelper;
use Exception;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Str;

/**
 * Class ProxyController
 */
class ProxyController extends Controller
{
    /**
     * ProxyController constructor.
     */
    public function __construct()
    {
        $this->middleware('can:view-any');
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function index(Navigation $navigation): View
    {
        $navigation->setTitle('Прокси');

        return view('resources.proxy.index', [
            'proxies' => Proxy::orderByDesc('is_active')->orderBy('name')->paginate()
        ]);
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function create(Navigation $navigation): View
    {
        $navigation->setTitle('Добавить прокси');

        return view('resources.proxy.create', [
            'types' => Proxy::types()
        ]);
    }

    /**
     * @param Navigation $navigation
     * @param Proxy $proxy
     * @return View
     */
    public function edit(Navigation $navigation, Proxy $proxy): View
    {
        $navigation->setTitle('Изменить прокси');

        return view('resources.proxy.edit', [
            'types' => Proxy::types(),
            'proxy' => $proxy
        ]);
    }

    /**
     * @param StoreRequest $request
     * @param ProxyHelper $helper
     * @return JsonResponse
     */
    public function store(StoreRequest $request, ProxyHelper $helper): JsonResponse
    {
        $proxy = new Proxy(
            $request->validated()
        );

        if(!$helper->valid($proxy->toConnectionString())) {
            return JsonResponse::error('Прокси невалиден.');
        }

        $proxy->save();
        $helper->reset();

        return JsonResponse::success('Прокси успешно добавлено.')->redirectToRoute('proxies.edit', $proxy);
    }

    /**
     * @param StoreManyRequest $request
     * @param ProxyHelper $helper
     * @return JsonResponse
     * @throws Exception
     */
    public function storeMany(StoreManyRequest $request, ProxyHelper $helper): JsonResponse
    {
        $proxies = explode("\n", $request->input('proxies'));
        $valid = $invalid = 0;

        foreach($proxies as $proxy) {
            $proxy = trim($proxy);

            if($helper->valid($proxy)) {
                $valid++;
                $result = $helper->stringToArray($proxy);
                $result['name'] = Str::limit($proxy, 97);
                $result['type'] = Proxy::getProtocolValue($result['protocol']);

                Proxy::create($result);

                continue;
            }

            $invalid++;
        }

        return JsonResponse::success("Успешно добавлено - {$valid}, пропущено - {$invalid}.")->redirectToRoute('proxies.index');
    }

    /**
     * @param UpdateRequest $request
     * @param ProxyHelper $helper
     * @param Proxy $proxy
     * @return JsonResponse
     */
    public function update(UpdateRequest $request, ProxyHelper $helper, Proxy $proxy): JsonResponse
    {
        $proxy->fill(
            $request->validated()
        );

        if(!$helper->valid($proxy->toConnectionString())) {
            return JsonResponse::error('Прокси невалиден.');
        }

        $proxy->is_active = 1;
        $proxy->save();
        $helper->reset();

        return JsonResponse::success('Прокси успешно изменен.');
    }

    /**
     * @param ProxyHelper $helper
     * @param Proxy $proxy
     * @return JsonResponse
     */
    public function destroy(ProxyHelper $helper, Proxy $proxy): JsonResponse
    {
        $proxy->delete();
        $helper->reset();

        return JsonResponse::success('Прокси успешно удален.')->redirectToRoute('proxies.index');
    }
}
