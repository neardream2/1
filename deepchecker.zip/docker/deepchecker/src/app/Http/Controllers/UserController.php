<?php

namespace App\Http\Controllers;

use App\Http\Requests\User\StoreRequest;
use App\Http\Requests\User\UpdateRequest;
use App\Models\User;
use App\Support\JsonResponse;
use App\Support\Navigation;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;

/**
 * Class UserController
 */
class UserController extends Controller
{
    /**
     * UserController constructor.
     */
    public function __construct()
    {
        $this->middleware('can:view-any');
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function index(Navigation $navigation): View
    {
        $navigation->setTitle('Пользователи');

        return view('resources.user.index', [
            'users' => User::latest()->withCount('wallets')->paginate()
        ]);
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function create(Navigation $navigation): View
    {
        $navigation->setTitle('Добавить пользователя');

        return view('resources.user.create', [
            'periods' => User::periods(),
            'groups' => User::groups()
        ]);
    }

    /**
     * @param Navigation $navigation
     * @param User $user
     * @return View
     */
    public function edit(Navigation $navigation, User $user): View
    {
        $navigation->setTitle('Изменить пользователя');

        return view('resources.user.edit', [
            'user' => $user,
            'periods' => User::periods(),
            'groups' => User::groups()
        ]);
    }

    /**
     * @param StoreRequest $request
     * @return JsonResponse
     */
    public function store(StoreRequest $request): JsonResponse
    {
        $attributes = $request->validated();
        $attributes['password'] = Hash::make($attributes['password']);

        $user = User::create($attributes);

        Cache::forget('telegram_admins');

        return JsonResponse::success('Пользователь успешно добавлен.')->redirectToRoute('users.edit', $user);
    }

    /**
     * @param UpdateRequest $request
     * @param User $user
     * @return JsonResponse
     */
    public function update(UpdateRequest $request, User $user): JsonResponse
    {
        $attributes = $request->validated();
        $attributes['password'] = $request->filled('password') ? Hash::make($attributes['password']) : $user->password;

        $user->update($attributes);

        Cache::forget('telegram_admins');

        return JsonResponse::success('Пользователь успешно изменен.');
    }

    /**
     * @param Request $request
     * @param User $user
     * @return JsonResponse
     */
    public function destroy(Request $request, User $user): JsonResponse
    {
        if($request->user()->id == $user->id) {
            return JsonResponse::error('Невозможно удалить свой аккаунт.');
        }

        $user->delete();

        Cache::forget('telegram_admins');

        return JsonResponse::success('Пользователь успешно удален.')->redirectToRoute('users.index');
    }
}
