<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateSettingsRequest;
use App\Models\Option;
use App\Models\User;
use App\Models\UserTelegram;
use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use App\Support\JsonResponse;
use App\Support\Navigation;
use App\Support\TelegramBot\Loader;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Throwable;

/**
 * Class SettingsController
 */
class SettingsController extends Controller
{
    /**
     * SettingsController constructor
     */
    public function __construct()
    {
        $this
            ->middleware('can:view-any')
            ->only('telegram', 'queues', 'reload');
    }

    /**
     * @param Request $request
     * @param Navigation $navigation
     * @param CurrencyBuilder $currencyBuilder
     * @return View
     * @throws FileNotFoundException
     */
    public function show(Request $request, Navigation $navigation, CurrencyBuilder $currencyBuilder): View
    {
        $navigation->setTitle('Настройки');

        $data = [
            'user' => $request->user(),
            'periods' => User::periods()
        ];

        if($request->user()->can('view-any')) {
            $data['currencies'] = $currencyBuilder->all();
            $data['license_date'] = Carbon::parse($_ENV['dddkadd']);
            $data['update'] = Cache::remember(
                'changelog', Carbon::now()->addHour(), fn(): string => Http::get('https://deepmng.com/api/changelog')->json('message') ?? ''
            );
        }

        return view('settings', $data);
    }

    /**
     * @param UpdateSettingsRequest $request
     * @param CurrencyBuilder $currencyBuilder
     * @return JsonResponse
     * @throws Throwable
     */
    public function update(UpdateSettingsRequest $request, CurrencyBuilder $currencyBuilder): JsonResponse
    {
        $attributes = $request->validated();
        $attributes['password'] = $request->filled('password') ? Hash::make($attributes['password']) : $request->user()->password;

        if($attributes['check_period'] != $request->user()->check_period) {
            $nextCheckDate = Carbon::now()->addMinutes($attributes['check_period']);
            $request->user()->wallets()->whereNotNull('addresses')->where('next_check_at', '>', $nextCheckDate)->update(['next_check_at' => $nextCheckDate]);
        }

        $request->user()->update($attributes);

        if($request->user()->can('view-any')) {
            $settings = $currencies = [];

            foreach($currencyBuilder->all() as $currency) {
                $result = [
                    'is_enabled' => $request->has('currencies.'.$currency->getSlug().'.is_enabled'),
                    'patches' => []
                ];

                foreach(array_keys($currency->getPatches()) as $patch) {
                    $result['patches'][$patch] = in_array($patch, $request->input('currencies.'.$currency->getSlug().'.patches') ?? []);
                }

                $currencies[$currency->getSlug()] = $result;
            }

            $settings['currencies'] = $currencies;
            $settings['telegram_bot_name'] = $request->input('telegram_bot_name');
            $settings['telegram_api_key'] = $request->input('telegram_api_key');
            $settings['blockchair_api_key'] = $request->input('blockchair_api_key');

            $settings = Arr::dot($settings);
            $settings = array_filter($settings, static fn(mixed $value): bool => $value !== null);

            DB::transaction(static function() use ($settings): void {
                Option::whereNotIn('key', array_keys($settings))->delete();

                foreach($settings as $key => $value) {
                    Option::updateOrCreate(compact('key'), compact('value'));
                }
            });

            Cache::forget('options');

            $this->reload();
        }

        $request->user()->is_admin && Cache::forget('telegram_admins');

        return JsonResponse::success('Настройки успешно обновлены.');
    }

    /**
     * @param Request $request
     * @param UserTelegram $telegram
     * @return JsonResponse
     */
    public function detachTelegramAccount(Request $request, UserTelegram $telegram): JsonResponse
    {
        if($request->user()->id != $telegram->user_id) {
            throw new NotFoundHttpException;
        }

        $telegram->delete();

        $request->user()->is_admin && Cache::forget('telegram_admins');

        return JsonResponse::success('Аккаунт успешно отвязан.')->redirectToRoute('settings.show');
    }

    /**
     * @param Loader $loader
     * @return JsonResponse
     */
    public function telegram(Loader $loader): JsonResponse
    {
        try {
            $loader->deleteWebhook();

            $result = $loader->setWebhook(
                route('api.telegram.get')
                //'https://b27d-8-21-110-78.ngrok.io/api/telegram/vDC79MRfbJ352shSI8jM'
            );

            return $result->isOk() ? JsonResponse::success($result->getDescription()) : JsonResponse::error($result->getDescription());
        }
        catch(Exception $e) {
            return JsonResponse::error($e->getMessage());
        }
    }

    /**
     * @return JsonResponse
     */
    public function queues(): JsonResponse
    {
        Wallet::chunk(500, static function(Collection $collection): void {
            $currentQueue = Wallet::MIN_QUEUE_ID;

            $collection->each(static function(Wallet $wallet) use (&$currentQueue): void {
                $wallet->queue_id = $currentQueue++;
                $wallet->save();

                if($currentQueue > Wallet::MAX_QUEUE_ID) {
                    $currentQueue = Wallet::MIN_QUEUE_ID;
                }
            });
        });

        return JsonResponse::success('Порядок очередей успешно изменен.');
    }

    /**
     * @return JsonResponse
     */
    public function reload(): JsonResponse
    {
        for($i = Wallet::MIN_QUEUE_ID; $i <= Wallet::MAX_QUEUE_ID; $i++) {
            Cache::forever("restart_{$i}_addresses", 1);
            Cache::forever("restart_{$i}_parse", 1);
        }

        return JsonResponse::success('Очереди будут перезапущены после завершения текущих задач.');
    }
}
