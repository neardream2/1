<?php

namespace App\Http\Controllers;

use App\Http\Requests\Wallet\StoreRequest;
use App\Http\Requests\Wallet\StoreTxtRequest;
use App\Models\User;
use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use App\Support\JsonResponse;
use App\Support\Mnemonic as MnemonicHelper;
use App\Support\Statistic;
use App\Support\StoreWalletsProgress;
use Carbon\Carbon;
use Closure;
use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Psr\SimpleCache\InvalidArgumentException;
use stdClass;

/**
 * Class WalletController
 */
class WalletController extends Controller
{
    protected ?User $user = null;

    protected ?Request $request = null;

    /**
     * WalletController constructor.
     */
    public function __construct()
    {
        $this->middleware(function(Request $request, Closure $next) {
            $this->request = $request;
            $this->user = $request->user();

            return $next($request);
        });

        $this->authorizeResource(Wallet::class);
    }

    /**
     * @param CurrencyBuilder $currencyBuilder
     * @return View
     */
    public function index(CurrencyBuilder $currencyBuilder): View
    {
        return view('resources.wallet.index', [
            'wallets' => $this->getWalletsPaginator()->withQueryString(),
            'query' => $this->request->input('s'),
            'order' => $this->getSearchOrder(),
            'order_values' => $this->getSearchOrderValues(),
            'currencyBuilder'=> $currencyBuilder,
            'locales' => MnemonicHelper::locales()
        ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function progress(Request $request): JsonResponse
    {
        $progress = new StoreWalletsProgress($request, $request->input('id'));

        return JsonResponse::success()->addData('progress', $progress->getProgress());
    }

    /**
     * @param Request $request
     * @param array $mnemonics
     * @return JsonResponse
     * @throws InvalidArgumentException
     */
    protected function storeMnemonics(Request $request, array $mnemonics): JsonResponse
    {
        $lock = Cache::lock('mnemonics_'.$request->user()->id, 7200);

        if($lock->get()) {
            $progress = new StoreWalletsProgress($request, $request->input('id'));
            $progress->setTotal(count($mnemonics));

            $wallets = new stdClass;
            $wallets->addedCount = $wallets->skippedCount = $wallets->duplicatesCount = $current = 0;

            Collection::make($mnemonics)
                ->chunk(1000)
                ->each(static function(Collection $mnemonics) use ($progress, $wallets, $request, &$current): void {
                    $current += $mnemonics->count();

                    $progress->setStatus(StoreWalletsProgress::STATUS_PREPARING);

                    $mnemonicsModelsData = new Collection;

                    foreach($mnemonics as $mnemonic) {
                        if(empty($mnemonic)) {
                            return;
                        }

                        $helper = new MnemonicHelper($mnemonic);

                        if($differences = $helper->getDifferences($request->input('locale'))) {
                            $request->user()->invalidMnemonics()->create([
                                'mnemonic' => $helper->getMnemonic(),
                                'invalid_words' => $differences
                            ]);
                            $wallets->skippedCount++;
                            return;
                        }

                        if(!$helper->isUnique($request->user())) {
                            $wallets->duplicatesCount++;
                            return;
                        }

                        $mnemonicsModelsData->add(['mnemonic' => $helper->getMnemonic(), 'next_check_at' => Carbon::now()]);
                    }

                    if($mnemonicsModelsData->isNotEmpty()) {
                        $progress->setStatus(StoreWalletsProgress::STATUS_CREATING);

                        $wallets->addedCount += $mnemonicsModelsData->count();
                        $request->user()->wallets()->createMany($mnemonicsModelsData);
                    }

                    $progress->setCurrentProgress($current);
                });

            $progress->setStatus(StoreWalletsProgress::STATUS_READY);

            $lock->release();

            Cache::forget('wallets_count');
            Cache::forget('wallets_count_'.$this->user->id);

            return JsonResponse::success("{$wallets->addedCount} добавлено в очередь; {$wallets->skippedCount} невалидных; {$wallets->duplicatesCount} дубликатов.")->redirectToRoute('index');
        }

        return JsonResponse::error('В данный момент уже происходит добавление мнемоников.');
    }

    /**
     * @param StoreRequest $request
     * @return JsonResponse
     * @throws InvalidArgumentException
     */
    public function store(StoreRequest $request): JsonResponse
    {
        return $this->storeMnemonics($request, explode("\n", $request->input('mnemonics')));
    }

    /**
     * @param StoreTxtRequest $request
     * @return JsonResponse
     * @throws InvalidArgumentException
     */
    public function storeTxt(StoreTxtRequest $request): JsonResponse
    {
        return $this->storeMnemonics($request, explode("\n", $request->file('txt')->getContent()));
    }

    /**
     * @param Wallet $wallet
     * @return JsonResponse
     */
    public function update(Wallet $wallet): JsonResponse
    {
        $wallet->notifications_enabled = !$wallet->notifications_enabled;
        $wallet->save();

        return JsonResponse::success(
            $wallet->notifications_enabled ? 'Уведомления успешно включены.' : 'Уведомления успешно отключены.'
        )->redirectToRoute('index');
    }

    /**
     * @param Wallet $wallet
     * @return JsonResponse
     */
    public function destroy(Wallet $wallet): JsonResponse
    {
        $wallet->delete();

        return JsonResponse::success('Кошелек успешно удален.')->redirectToRoute('index');
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function truncate(Request $request): JsonResponse
    {
        $request->user()->wallets()->delete();

        return JsonResponse::success('Все кошельки успешно удалены.')->redirectToRoute('index');
    }

    /**
     * @param Request $request
     * @param int $page
     * @return JsonResponse
     */
    public function destroyForPage(Request $request, int $page): JsonResponse
    {
        $request->user()->wallets()->forPage($page)->delete();

        return JsonResponse::success("Кошельки для страницы {$page} успешно удалены.")->redirectToRoute('index');
    }

    /**
     * @return Paginator
     */
    protected function getWalletsPaginator(): Paginator
    {
        $builder = $this->user->is_admin ? Wallet::query()->with('user') : $this->user->wallets();

        if($this->request->filled('s')) {
            $query = $this->request->input('s');

            if(is_string($query) && Str::length($query) >= 3 && Str::length($query) <= 255) {
                $query = '%'.str_replace(['%', '_'], '', $query).'%';
                $builder->whereRaw('(mnemonic like ? or addresses like ?)', [$query, $query]);
            }
        }

        $order = $this->getSearchOrder();

        if($order['field'] && $order['direction']) {
            $values = $this->getSearchOrderValues();
            $order['field'] = match($order['field']) {
                $values['fields'][0] => 'cast(latest_result->"$.total" as decimal)',
                $values['fields'][1] => 'created_at',
                default => 'updated_at'
            };

            //$builder->orderBy($order['field'], $order['direction']);
            $builder->orderByRaw($order['field'].' '.$order['direction']);
        }
        else {
            $builder->orderByDesc('updated_at');
        }

        return (new Statistic)->isTooManyWallets($this->user) ? $builder->simplePaginate() : $builder->paginate();
    }

    /**
     * @return array<string>
     */
    protected function getSearchOrder(): array
    {
        $fields = [];
        $values = $this->getSearchOrderValues();

        $orderBy = $this->request->input('direction');
        $fields['direction'] = is_string($orderBy) && in_array($orderBy, $values['direction']) ? $orderBy : null;

        $orderByField = $this->request->input('field');
        $fields['field'] = is_string($orderByField) && in_array($orderByField, $values['fields']) ? $orderByField : null;


        return $fields;
    }

    /**
     * @return array<string>
     */
    protected function getSearchOrderValues(): array
    {
        return [
            'direction' => ['asc', 'desc'],
            'fields' => ['total', 'created_at']
        ];
    }
}
