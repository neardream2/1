<?php

namespace App\Http\Controllers;

use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use Closure;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Class ExportController
 */
class ExportController extends Controller
{
    protected ?Request $request = null;

    protected int $lazyLimit = 1000;

    /**
     * ExportController constructor
     */
    public function __construct()
    {
        $this->middleware(function(Request $request, Closure $next) {
            $this->request = $request;

            return $next($request);
        });
    }

    /**
     * @return StreamedResponse
     */
    public function mnemonics(): StreamedResponse
    {
        $callback = function() {
            $this->builder()->chunk(
                $this->lazyLimit,
                static function(Collection $collection): void {
                    $collection->each(static function(Wallet $wallet) use (&$stream): void {
                        file_put_contents('php://output', $wallet->mnemonic."\n", FILE_APPEND);
                    });
                }
            );
        };

        return new StreamedResponse(
            $callback, Response::HTTP_OK,
            [
                'Content-Type' => 'text/plain',
                'Content-Disposition' => 'attachment; filename=mnemonics.txt'
            ]
        );
    }

    /**
     * @param Request $request
     * @param CurrencyBuilder $currencyBuilder
     * @return StreamedResponse
     */
    public function addresses(Request $request, CurrencyBuilder $currencyBuilder): StreamedResponse
    {
        if(!$request->filled('currency') || !$currencyBuilder->has($request->get('currency'))) {
            throw new NotFoundHttpException;
        }

        $currency = $request->get('currency');

        $callback = function() use ($currency) {
            $this->builder()->whereNotNull('latest_result')->chunk(
                $this->lazyLimit,
                static function(Collection $collection) use ($currency): void {
                    $collection->each(static function(Wallet $wallet) use (&$stream, $currency): void {
                        foreach($wallet->addresses[$currency] ?? [] as $address) {
                            file_put_contents('php://output', $address."\n", FILE_APPEND);
                        }
                    });
                }
            );
        };

        return new StreamedResponse(
            $callback, Response::HTTP_OK,
            [
                'Content-Type' => 'text/plain',
                'Content-Disposition' => "attachment; filename=addresses_{$currency}.txt"
            ]
        );
    }

    /**
     * @return EloquentBuilder|Builder
     */
    protected function builder(): mixed
    {
        return $this->request->user()->can('view-any')
            ? Wallet::query()
            : $this->request->user()->wallets();
    }
}
