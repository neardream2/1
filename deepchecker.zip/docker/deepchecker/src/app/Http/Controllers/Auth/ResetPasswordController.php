<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Support\JsonResponse;
use App\Support\Navigation;
use Illuminate\Contracts\View\View;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * @param Request $request
     * @param Navigation $navigation
     * @return View
     */
    public function showResetForm(Request $request, Navigation $navigation): View
    {
        $navigation->setTitle('Изменить пароль');

        return view('auth.passwords.reset')->with([
            'token' => $request->route()->parameter('token'),
            'email' => $request->input('email')
        ]);
    }

    /**
     * @param Request $request
     * @param $response
     * @return JsonResponse
     */
    protected function sendResetResponse(Request $request, $response): JsonResponse
    {
        return JsonResponse::success(trans($response))->redirectToRoute('index');
    }
}
