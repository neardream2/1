<?php

namespace App\Http\Controllers;

use App\Models\InvalidMnemonic;
use App\Support\Navigation;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

/**
 * Class InvalidMnemonicController
 */
class InvalidMnemonicController extends Controller
{
    /**
     * @param Request $request
     * @param Navigation $navigation
     * @return View
     */
    public function __invoke(Request $request, Navigation $navigation): View
    {
        $navigation->setTitle('Неудачные Seed-фразы');

        return view('resources.wallet.invalid', [
            'mnemonics' => $request->user()->invalidMnemonics()->latest()->paginate()
        ]);
    }
}