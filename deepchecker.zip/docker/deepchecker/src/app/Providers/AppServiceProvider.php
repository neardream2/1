<?php

namespace App\Providers;

use App\Http\ViewComposers\NavigationComposer;
use App\Http\ViewComposers\StatisticComposer;
use App\Http\ViewComposers\VersionComposer;
use App\Http\ViewComposers\WalletsCountComposer;
use App\Models\Option;
use App\Support\CurrencyBuilder;
use App\Support\Navigation;
use App\Support\TelegramBot\Loader;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Longman\TelegramBot\Telegram;

/**
 * Class AppServiceProvider
 */
class AppServiceProvider extends ServiceProvider
{
    protected array $viewComposers = [
        NavigationComposer::class => 'layouts.*',
        WalletsCountComposer::class => 'layouts.app',
        StatisticComposer::class => 'layouts.app',
        VersionComposer::class => 'particles.version'
    ];

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(): void
    {
        $this->app->singleton(Navigation::class);
        $this->app->singleton(Loader::class);
        $this->app->bind(Telegram::class, static fn(Application $app): Telegram => new Telegram($app['config']->get('autoload.telegram_api_key', ''), $app['config']->get('autoload.telegram_bot_name', '')));
        $this->app->singleton(CurrencyBuilder::class);

        View::composers($this->viewComposers);
        Paginator::useBootstrap();

        Option::loadToConfig();
    }
}
