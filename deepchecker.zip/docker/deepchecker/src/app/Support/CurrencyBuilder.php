<?php

namespace App\Support;

use App\Support\Currency\Currency;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;

/**
 * Class CurrencyBuilder
 */
class CurrencyBuilder
{
    protected array $currencies = [];

    /**
     * CurrencyBuilder constructor.
     */
    public function __construct()
    {
        $this->loadCurrencies();
    }

    /**
     * @param Currency|string $currency
     * @return $this
     */
    public function add(Currency|string $currency): self
    {
        $currency = is_string($currency) ? new $currency : $currency;
        $this->currencies[$currency->getSlug()] = $currency;

        return $this;
    }

    /**
     * @param string $slug
     * @return Currency
     * @throws Exception
     */
    public function get(string $slug): Currency
    {
        $currency = $this->currencies[$slug] ?? null;

        if(!$currency) {
            throw new Exception("Currency {$slug} not found.");
        }

        return $currency;
    }

    /**
     * @param string $slug
     * @return bool
     */
    public function has(string $slug): bool
    {
        try {
            $this->get($slug);
            return true;
        }
        catch(Exception) {
            return false;
        }
    }

    /**
     * @return array|Currency[]
     */
    public function all(): array
    {
        return $this->currencies;
    }

    /**
     * @return array
     */
    public function allEnabled(): array
    {
        return array_filter(
            $this->all(),
            static fn(Currency $currency): bool => $currency->isEnabled()
        );
    }

    public function slugs(bool $withDisabled = true): array
    {
        return Collection::make($this->all())
            ->when(
                !$withDisabled,
                static fn(Collection $collection): Collection => $collection->filter(static fn(Currency $currency): bool => $currency->isEnabled())
            )
            ->map->getSlug()->all();
    }

    public function getChangedValues(array $result, int $minimal): array
    {
        $data = [];

        foreach($this->allEnabled() as $currency) {
            $currencyData = $result[$currency->getSlug()] ?? null;

            if(!$currencyData) {
                continue;
            }

            foreach($currencyData as $address => $value) {
                $value = is_array($value) ? array_sum($value) : $value;

                if($value > $minimal) {
                    $data[$currency->getSlug()] ??= [];
                    $data[$currency->getSlug()][$address] = $value;
                }
            }
        }

        return $data;
    }

    /**
     * @return void
     */
    protected function loadCurrencies(): void
    {
        foreach(Config::get('jamasad.currencies', []) as $currency) {
            $this->add($currency);
        }
    }
}
