<?php

namespace App\Support;

use App\Models\User;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;

/**
 * Class Statistic
 */
class Statistic
{
    public const ADDRESSES_KEY = 'addresses';
    public const PARSE_KEY = 'parser';

    /**
     * @param string $key
     * @param int|bool $execTime
     * @return $this
     */
    public function put(string $key, int|bool $execTime): self
    {
        !Cache::has("statistic_timer_{$key}") && Cache::put("statistic_timer_{$key}", $execTime, Carbon::now()->addHour());

        return $this;
    }

    /**
     * @return int
     */
    public function get(): int
    {
        $execAddressesTime = Cache::get('statistic_timer_'.self::ADDRESSES_KEY);
        $execParseTime = Cache::get('statistic_timer_'.self::PARSE_KEY);

        $callback = static function() use ($execAddressesTime, $execParseTime): int {
            $addressesLength = Wallet::whereNull('addresses')->count();
            $parseLength = Wallet::whereIsNeedCheck()->count();

            return intval(
                (($execAddressesTime * $addressesLength / 10) + ($execParseTime * $parseLength / 5)) / 60
            );
        };

        return $this->isTooManyWallets()
            ? Cache::remember('statistic_timer_left', Carbon::now()->addMinute(), $callback)
            : $callback();
    }

    /**
     * @param User|null $user
     * @return bool
     */
    public function isTooManyWallets(?User $user = null): bool
    {
        return $this->walletsCount($user) <= 100000;
    }

    /**
     * @param User|null $user
     * @return int
     */
    public function walletsCount(?User $user = null): int
    {
        return Cache::remember(
            !$user || $user->is_admin ? 'wallets_count' : 'wallets_count_'.$user->id,
            Carbon::now()->addHour(), static fn(): int => !$user || $user->is_admin ? Wallet::count() : $user->wallets()->count()
        );
    }
}
