<?php

namespace App\Support\Services;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Proxy;
use Exception;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Promise\PromiseInterface;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;

/**
 * Class Blockchair
 */
class Blockchair
{
    /**
     * @param string $block
     * @param array $addresses
     * @return array
     * @throws WalletNotFoundException
     */
    public function getBalances(string $block, array $addresses): array
    {
        try {
            $response = $this->http("{$block}/addresses/balances", ['addresses' => implode(',', $addresses)]);
        }
        catch(Exception $exception) {
            Log::error("Blockchair error", ['message' => $exception->getMessage()]);
            throw new WalletNotFoundException;
        }

        if(!$response->successful()) {
            Log::error("Blockchair error", ['response' => $response->body()]);
            throw new WalletNotFoundException;
        }

        $data = $response->json('data') ?? [];
        $result = [];

        foreach($addresses as $address) {
            $result[$address] = $data[$address] ?? 0;
        }

        return $result;
    }

    /**
     * @param string $endPoint
     * @param array $parameters
     * @return Response
     * @throws Exception
     */
    public function http(string $endPoint, array $parameters = []): Response
    {
        $http = Http::asJson();

        if(Config::has('autoload.blockchair_api_key')) {
            $parameters['key'] = Config::get('autoload.blockchair_api_key');
        }
        else {
            $http->withOptions(['proxy' => (new Proxy)->pluckForService(self::class)]);
        }

        return $http->throw()->get("https://api.blockchair.com/{$endPoint}", $parameters);
    }
}
