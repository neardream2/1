<?php

namespace App\Support\Services;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Proxy;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Class Blockchain
 */
class Blockchain
{
    private ?array $cachedExchangeRates = null;

    /**
     * @param array $addresses
     * @return array
     * @throws WalletNotFoundException
     */
    public function getBalances(array $addresses): array
    {
        $addressesString = implode('|', $addresses);
        $proxy = (new Proxy)->pluckForService('blockchain.info');

        $response = Http::withOptions(compact('proxy'))->get('https://blockchain.info/balance', [
            'active' => $addressesString
        ]);

        if(!$response->successful()) {
            Log::error("Blockchain error: $addressesString", ['response' => $response->body(), 'proxy' => $proxy]);
            throw new WalletNotFoundException;
        }

        $json = $response->json();
        $result = [];

        foreach($addresses as $address) {
            $result[$address] = isset($json[$address]['final_balance']) ? $json[$address]['final_balance'] / 100000000 : 0;
        }

        return $result;
    }

    /**
     * @param string $address
     * @return float
     * @throws WalletNotFoundException
     */
    public function getBalance(string $address): float
    {
        return $this->getBalances([$address])[$address];
    }

    /**
     * @param int|float $amount
     * @return int
     */
    public function getBtcToUsd(int|float $amount): int
    {
        return (int) round(($amount / 100000000) * $this->getExchangeRate('USD'), mode: PHP_ROUND_HALF_EVEN);
    }

    /**
     * @param string $currency
     * @return int|float
     */
    public function getExchangeRate(string $currency): int|float
    {
        return $this->getExchangeRates()[$currency] ?? 1;
    }

    /**
     * @return array
     */
    public function getExchangeRates(): array
    {
        if($this->cachedExchangeRates === null) {
            $this->cachedExchangeRates = Cache::remember('exchange_rates', Carbon::now()->addMinutes(10), static function(): array {
                $response = Http::get('https://blockchain.info/ticker');

                if(!$response->successful()) {
                    return [];
                }

                $result = [];

                foreach($response->json() as $currency => $values) {
                    $result[$currency] = $values['last'];
                }

                return $result;
            });
        }

        return $this->cachedExchangeRates;
    }
}
