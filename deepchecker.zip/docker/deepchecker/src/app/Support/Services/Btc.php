<?php

namespace App\Support\Services;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Proxy;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Class Btc
 */
class Btc
{
    /**
     * @param string $address
     * @param string|null $proxy
     * @return int|float
     * @throws WalletNotFoundException
     */
    public function getBalance(string $address, ?string $proxy = null): int|float
    {
        $proxy ??= (new Proxy)->pluck();
        $response = Http::withOptions(compact('proxy'))->get("https://bch-chain.api.btc.com/v3/address/{$address}");

        if(!$response->successful()) {
            Log::error("BTC.com error: $address", ['response' => $response->body(), 'proxy' => $proxy]);
            throw new WalletNotFoundException;
        }

        $json = $response->json();

        return $json['data']['balance'] ?? 0;
    }
}