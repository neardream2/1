<?php

namespace App\Support\Services;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Proxy;
use GuzzleHttp\Exception\ConnectException;
use Carbon\Carbon;
use Illuminate\Http\Client\Pool;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Class SoChain
 */
class SoChain
{
    public const DEFAULT_CURRENCY = 'USD';

    /**
     * @param string $from
     * @param string $to
     * @return int|float
     */
    public function getExchangeRate(string $from, string $to = self::DEFAULT_CURRENCY): int|float
    {
        return Cache::remember("so_chain_{$from}_{$to}", Carbon::now()->addMinutes(10), static function() use ($from, $to): int|float {
            $response = Http::get("https://sochain.com/api/v2/get_price/{$from}/$to");

            if($response instanceof ConnectException || !$response->successful()) {
                return 1;
            }

            $json = $response->json();

            return $json['data']['prices'][0]['price'] ?? 1;
        });
    }

    /**
     * @param string $currency
     * @param array $addresses
     * @return array
     */
    public function getBalances(string $currency, array $addresses): array
    {
        $responses = Http::pool(static function(Pool $pool) use ($currency, $addresses): void {
            foreach($addresses as $address) {
                $pool
                    ->as($address)
                    ->withHeaders(['proxy' => (new Proxy)->pluckForService('chain.so')])
                    ->get("https://chain.so/api/v2/get_address_balance/{$currency}/{$address}");
            }
        });

        $result = [];

        foreach($responses as $address => $response) {
            if($response instanceof ConnectException) {
                Log::error("chain.so error: $address", ['message' => $response->getMessage()]);
                continue;
            }

            if(!$response->successful()) {
                Log::error("chain.so error: $address", ['response' => $response->body()]);
                continue;
            }

            $json = $response->json();
            $result[$address] = $json['data']['confirmed_balance'] ?? 0;
        }

        return $result;
    }

    /**
     * @param string $currency
     * @param string $address
     * @return int|float
     * @throws WalletNotFoundException
     */
    public function getBalance(string $currency, string $address): int|float
    {
        $proxy = (new Proxy)->pluckForService('chain.so');

        try {
            $response = Http::withOptions(compact('proxy'))->get("https://chain.so/api/v2/get_address_balance/{$currency}/{$address}");
        }
        catch(ConnectException $exception) {
            Log::error("chain.so error: $address", ['message' => $exception->getMessage(), 'proxy' => $proxy]);
            throw new WalletNotFoundException;
        }

        if(!$response->successful()) {
            Log::error("chain.so error: $address", ['response' => $response->body(), 'proxy' => $proxy]);
            throw new WalletNotFoundException;
        }

        $json = $response->json();

        return $json['data']['confirmed_balance'] ?? 0;
    }
}
