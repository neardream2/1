<?php

namespace App\Support\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Class FullstackCash
 */
class FullstackCash
{
    /**
     * @return int|float
     */
    public function getBchToUsd(): int|float
    {
        return Cache::remember("bch_usd_rate", Carbon::now()->addMinutes(10), static function(): int|float {
            $response = Http::get('https://api.fullstack.cash/v5/price/usd');

            if(!$response->successful()) {
                return 1;
            }

            return $response->json('usd') ?? 1;
        });
    }
}
