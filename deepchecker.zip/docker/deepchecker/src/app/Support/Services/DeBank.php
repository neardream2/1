<?php

namespace App\Support\Services;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Proxy;
use Illuminate\Http\Client\Pool;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Class DeBank
 */
class DeBank
{
    public const TIMEOUT = 20;
    public const CHAIN_ID = 'eth';
    public const API_PREFIX = 'https://openapi.debank.com';

    /**
     * @param array $addresses
     * @param string $chain
     * @return array
     */
    public function getResults(array $addresses, string $chain = self::CHAIN_ID): array
    {
        $responses = Http::pool(static function(Pool $pool) use ($addresses, $chain): void {
            foreach($addresses as $address) {
                $proxy = (new Proxy)->pluckForService('debank.com');
                $query = ['chain_id' => $chain, 'id' => $address];

                $pool
                    ->as($address.'_balance')
                    ->withOptions(compact('proxy'))
                    ->get(self::API_PREFIX.'/v1/user/total_balance', $query);

                $pool
                    ->as($address.'_list')
                    ->withOptions(compact('proxy'))
                    ->get(self::API_PREFIX.'/v1/user/nft_list', $query);
            }
        });

        $result = [];

        foreach($addresses as $address) {
            $balanceResponse = $responses[$address.'_balance'];
            $nftListResponse = $responses[$address.'_list'];

            if(!$balanceResponse->successful() || !$nftListResponse->successful()) {
                $response = $balanceResponse->successful() ? $nftListResponse : $balanceResponse;
                Log::error("DeBank error: $address", ['response' => $response->body()]);
                continue;
            }

            $balanceJson = $balanceResponse->json();
            $nftListCollection = Collection::make($nftListResponse->json());

            $total = isset($balanceJson['total_usd_value']) ? $this->round($balanceJson['total_usd_value']) : 0;
            $nft = $this->round($nftListCollection->whereNotNull('usd_price')->sum('usd_price'));

            $result[$address] = compact('total', 'nft');
        }

        return $result;
    }

    /**
     * @param string $address
     * @param string $chain
     * @return int
     * @throws WalletNotFoundException
     */
    public function totalBalance(string $address, string $chain = self::CHAIN_ID): int
    {
        $response = $this->query('/v1/user/total_balance', [
            'chain_id' => $chain,
            'id' => $address
        ]);

        if(!$response->successful()) {
            Log::error("DeBank error: $address", ['response' => $response->body()]);
            throw new WalletNotFoundException;
        }

        $json = $response->json();

        return isset($json['total_usd_value']) ? $this->round($json['total_usd_value']) : 0;
    }

    /**
     * @param string $address
     * @param string $chain
     * @return Collection
     * @throws WalletNotFoundException
     */
    public function NFTList(string $address, string $chain = self::CHAIN_ID): Collection
    {
        $response = $this->query('/v1/user/nft_list', [
            'chain_id' => $chain,
            'id' => $address
        ]);

        if(!$response->successful()) {
            throw new WalletNotFoundException;
        }

        return Collection::make($response->json());
    }

    /**
     * @param string $address
     * @param string $chain
     * @return int
     * @throws WalletNotFoundException
     */
    public function NFTNetWorth(string $address, string $chain = self::CHAIN_ID): int
    {
        return $this->round(
            $this->nftList($address, $chain)->whereNotNull('usd_price')->sum('usd_price')
        );
    }

    /**
     * @param string $endPoint
     * @param array $parameters
     * @return Response
     */
    private function query(string $endPoint, array $parameters): Response
    {
        return Http::withOptions([
            'timeout' => self::TIMEOUT,
            'proxy' => (new Proxy)->pluckForService('debank.com')
        ])->get(self::API_PREFIX.$endPoint, $parameters);
    }

    private function round(int|float $value): int
    {
        return (int) round($value, mode: PHP_ROUND_HALF_EVEN);
    }
}
