<?php

namespace App\Support\Services;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Proxy;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Psr\SimpleCache\InvalidArgumentException;

/**
 * Class Bitcoin
 */
class Bitcoin
{
    /**
     * @param string $address
     * @param string|null $proxy
     * @return int|float
     * @throws WalletNotFoundException
     */
    public function getBalance(string $address, ?string $proxy = null): int|float
    {
        $proxy ??= (new Proxy)->pluck();
        $response = Http::withOptions(compact('proxy'))->get("https://explorer.api.bitcoin.com/bch/v1/addr/{$address}/balance");

        if(!$response->successful()) {
            Log::error("Bitcoin.com error: {$address}", ['response' => $response->body(), 'proxy' => $proxy]);
            throw new WalletNotFoundException;
        }

        $balance = $response->body();

        return is_numeric($balance) ? $balance : 0;
    }

    /**
     * @param string $address
     * @return int|float
     * @throws InvalidArgumentException
     * @throws WalletNotFoundException
     */
    public function getBalanceWithSupportedService(string $address): int|float
    {
        $proxy = (new Proxy)->pluckForService('bitcoin.com');
        $latestPing = Cache::get('bitcoin_com_'.($proxy ?? '').'_latest_ping');

        if($latestPing && $latestPing <= Carbon::now()->subSeconds(12)->format('YmdHis')) {
            return (new Btc)->getBalance($address, $proxy);
        }

        Cache::set('bitcoin_com_'.($proxy ?? '').'_latest_ping', Carbon::now()->format('YmdHis'), Carbon::now()->addHour());

        return $this->getBalance($address, $proxy);
    }
}
