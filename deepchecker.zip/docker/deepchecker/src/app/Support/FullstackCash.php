<?php

namespace App\Support;

/**
 * Class FullstackCash
 * @deprecated Перенесен в App\Support\Services
 */
class FullstackCash extends \App\Support\Services\FullstackCash {}
