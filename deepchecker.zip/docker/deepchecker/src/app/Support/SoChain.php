<?php

namespace App\Support;

/**
 * Class SoChain
 * @deprecated Перенесен в App\Support\Services
 */
class SoChain extends \App\Support\Services\SoChain {}
