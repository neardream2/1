<?php

namespace App\Support\Exceptions;

use Exception;

/**
 * Class WalletNotFoundException
 */
class WalletNotFoundException extends Exception {}