<?php

namespace App\Support;

/**
 * Class Blockchain
 * @deprecated Перенесен в App\Support\Services
 */
class Blockchain extends \App\Support\Services\Blockchain {}
