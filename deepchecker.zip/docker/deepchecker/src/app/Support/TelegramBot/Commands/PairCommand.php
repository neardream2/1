<?php

/**
 * This file is part of the PHP Telegram Bot example-bot package.
 * https://github.com/php-telegram-bot/example-bot/
 *
 * (c) PHP Telegram Bot Team
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * Start command
 *
 * Gets executed when a user first starts using the bot.
 *
 * When using deep-linking, the parameter can be accessed by getting the command text.
 *
 * @see https://core.telegram.org/bots#deep-linking
 */

namespace App\Support\TelegramBot\Commands;

use App\Models\User;
use App\Models\UserTelegram;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Longman\TelegramBot\Commands\SystemCommand;
use Longman\TelegramBot\Entities\ServerResponse;
use Longman\TelegramBot\Exception\TelegramException;
use Throwable;

/**
 * Class StartCommand
 * @package App\Support\TelegramBot\Commands
 */
class PairCommand extends SystemCommand
{
    /**
     * @var string
     */
    protected $name = 'pair';

    /**
     * @var string
     */
    protected $description = 'Pair command';

    /**
     * @var string
     */
    protected $usage = '/pair';

    /**
     * @return ServerResponse
     * @throws TelegramException
     * @throws Throwable
     */
    public function execute(): ServerResponse
    {
        $key = $this->getMessage()->getText(true);

        if(!is_string($key)) {
            return $this->replyToChat('Ключ не указан.');
        }

        $user = User::whereHas('telegramCode', static fn(Builder $builder) => $builder->where('code', $key))->first();

        if(!$user) {
            return $this->replyToChat('Ключ не найден.');
        }

        if($user->telegrams()->count() >= 20) {
            return $this->replyToChat('Максимальное количество привязанных Telegram-чатов - 20.');
        }

        if($telegramChat = UserTelegram::firstWhere('chat_id', $this->getMessage()->getChat()->getId())) {
            return $this->replyToChat(
                $telegramChat->chat_id == $user->id
                    ? 'Данный чат уже привязан к текущему профилю.'
                    : 'Данный чат уже привязан к другому профилю.'
            );
        }

        DB::transaction(function() use ($user): void {
            $user->telegrams()->create([
                'name' => Str::limit($this->getMessage()->getChat()->getUsername() ?? 'n/a', 97),
                'chat_id' => $this->getMessage()->getChat()->getId()
            ]);

            $user->telegramCode()->delete();
        });

        $user->is_admin && Cache::forget('telegram_admins');

        return $this->replyToChat('Привязка успешно совершена.');
    }
}
