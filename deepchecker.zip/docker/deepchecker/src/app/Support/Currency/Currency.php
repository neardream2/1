<?php

namespace App\Support\Currency;

use App\Support\Proxy;
use BitWasp\Bitcoin\Key\Deterministic\HierarchicalKey;
use BitWasp\Bitcoin\Key\Factory\HierarchicalKeyFactory;
use BitWasp\Bitcoin\Mnemonic\Bip39\Bip39SeedGenerator;
use BitWasp\Buffertools\BufferInterface;
use Exception;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Class Currency
 */
abstract class Currency
{
    /**
     * @param string $mnemonic
     * @return array<string>
     */
    abstract public function getAddresses(string $mnemonic): array;

    abstract public function getResult(array $addresses): array;

    abstract public function getLink(string $address): string;

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return !Config::has('autoload.currencies.'.$this->getSlug().'.is_enabled') || Config::get('autoload.currencies.'.$this->getSlug().'.is_enabled');
    }

    /**
     * @param string $path
     * @return bool
     */
    public function isEnabledPatch(string $path): bool
    {
        return (!Config::has('autoload.currencies.'.$this->getSlug().'.patches.'.$path) && Str::substr($path, -1, 1) < 3)
            || Config::get('autoload.currencies.'.$this->getSlug().'.patches.'.$path);
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return property_exists($this, 'name') ? $this->name : class_basename($this);
    }

    /**
     * @return string
     */
    public function getSlug(): string
    {
        return property_exists($this, 'slug') ? $this->slug : Str::snake($this->getName());
    }

    /**
     * @return array
     */
    public function getPatches(): array
    {
        $patches = [];

        if(!property_exists($this, 'patches')) {
            return $patches;
        }

        $isList = array_is_list($this->patches);

        foreach($this->patches as $spec => $value) {
            if(is_array($value)) {
                foreach($value as $patch) {
                    $patches[$isList ? $patch : $spec.'|'.$patch] = $isList ? $value : "BIP{$spec}: {$patch}";
                }
            }
            else {
                $patches[$isList ? $value : $spec.'|'.$value] = $isList ? $value : "BIP{$spec}: {$value}";
            }
        }

        return $patches;
    }

    /**
     * @param array $result
     * @return int|float
     */
    public function getTotal(array $result): int|float
    {
        $total = 0;

        foreach($result as $value) {
            if(is_array($value)) {
                $total += array_sum($value);
            }
            else {
                $total += $value;
            }
        }

        return $total;
    }

    /**
     * @return PendingRequest
     */
    protected function getHttp(): PendingRequest {
        return Http::withOptions([
            'proxy' => (new Proxy)->pluck()
        ]);
    }

    /**
     * @param string $mnemonic
     * @return BufferInterface
     * @throws Exception
     */
    protected function getSeed(string $mnemonic): BufferInterface
    {
        return (new Bip39SeedGenerator)->getSeed($mnemonic);
    }

    /**
     * @param BufferInterface $seed
     * @return HierarchicalKey
     * @throws Exception
     */
    protected function getKey(BufferInterface $seed): HierarchicalKey
    {
        return (new HierarchicalKeyFactory)->fromEntropy($seed);
    }
}
