<?php

namespace App\Support\Currency;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Services\Blockchair;
use App\Support\Services\FullstackCash;
use Btccom\BitcoinCash\Address\AddressCreator as BitcoinCashAddressCreator;
use Btccom\BitcoinCash\Network\Networks\BitcoinCash as BitcoinCashNetwork;
use Exception;
use Illuminate\Support\Str;

/**
 * Class BitcoinCash
 */
class BitcoinCash extends Currency
{
    protected string $slug = 'bch';

    protected array $patches = [
        "0'/0'/0", "0'/0'/1", "0'/0'/2", "0'/0'/3", "0'/0'/4", "0'/0'/5", "0'/0'/6", "0'/0'/7", "0'/0'/8", "0'/0'/9",
        "44'/145'/0'/0", "44'/145'/0'/1", "44'/145'/0'/2", "44'/145'/0'/3", "44'/145'/0'/4", "44'/145'/0'/5", "44'/145'/0'/6", "44'/145'/0'/7", "44'/145'/0'/8", "44'/145'/0'/9",
        "44'/145'/0'/0/0", "44'/145'/0'/0/1", "44'/145'/0'/0/2", "44'/145'/0'/0/3", "44'/145'/0'/0/4", "44'/145'/0'/0/5", "44'/145'/0'/0/6", "44'/145'/0'/0/7", "44'/145'/0'/0/8", "44'/145'/0'/0/9"
    ];

    /**
     * @param string $mnemonic
     * @return array
     * @throws Exception
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $key = $this->getKey($this->getSeed($mnemonic));
        $addressCreator = new BitcoinCashAddressCreator;
        $network = new BitcoinCashNetwork;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            $addresses[$patch] = $key->derivePath($patch)
                ->getAddress($addressCreator)
                ->getAddress($network);
        }

        return $addresses;
    }

    /**
     * @param array $addresses
     * @return array
     */
    public function getResult(array $addresses): array
    {
        $blockchair = new Blockchair;
        $rate = (new FullstackCash)->getBchToUsd();

        try {
            $balances = $blockchair->getBalances(
                'bitcoin-cash',
                array_map(static fn(string $address): string => Str::after($address, 'bitcoincash:'), $addresses)
            );
        }
        catch(WalletNotFoundException) {
            $balances = [];
        }

        $result = [];

        foreach($balances as $address => $balance) {
            $result["bitcoincash:{$address}"] = $balance > 0 ? round(($balance / 100000000) * $rate, 2, mode: PHP_ROUND_HALF_EVEN) : 0;
        }

        return $result;
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://www.blockchain.com/bch/address/{$address}";
    }
}
