<?php

namespace App\Support\Currency;

use App\Support\Services\SoChain;
use BitWasp\Bitcoin\Address\AddressCreator;
use BitWasp\Bitcoin\Address\PayToPubKeyHashAddress;
use BitWasp\Bitcoin\Address\SegwitAddress;
use BitWasp\Bitcoin\Key\Factory\HierarchicalKeyFactory;
use BitWasp\Bitcoin\Network\Networks\Litecoin as LitecoinNetwork;
use BitWasp\Bitcoin\Script\P2shScript;
use BitWasp\Bitcoin\Script\ScriptFactory;
use BitWasp\Bitcoin\Script\WitnessProgram;
use Exception;

/**
 * Class Litecoin
 */
class Litecoin extends Currency
{
    protected string $slug = 'ltc';

    protected array $patches = [
        32 => ["0'/0'/0", "0'/0'/1", "0'/0'/2", "0'/0'/3", "0'/0'/4", "0'/0'/5", "0'/0'/6", "0'/0'/7", "0'/0'/8", "0'/0'/9"],
        44 => [
            "44'/2'/0'/0", "44'/2'/0'/1", "44'/2'/0'/2", "44'/2'/0'/3", "44'/2'/0'/4", "44'/2'/0'/5", "44'/2'/0'/6", "44'/2'/0'/7", "44'/2'/0'/8", "44'/2'/0'/9",
            "44'/2'/0'/0/0", "44'/2'/0'/0/1", "44'/2'/0'/0/2", "44'/2'/0'/0/3", "44'/2'/0'/0/4", "44'/2'/0'/0/5", "44'/2'/0'/0/6", "44'/2'/0'/0/7", "44'/2'/0'/0/8", "44'/2'/0'/0/9"
        ],
        49 => ["0/0", "0/1", "0/2", "0/3", "0/4", "0/5", "0/6", "0/7", "0/8", "0/9"],
        84 => ["84'/2'/0'/0/0", "84'/2'/0'/0/1", "84'/2'/0'/0/2", "84'/2'/0'/0/3", "84'/2'/0'/0/4", "84'/2'/0'/0/5", "84'/2'/0'/0/6", "84'/2'/0'/0/7", "84'/2'/0'/0/8", "84'/2'/0'/0/9"]
    ];

    /**
     * @param string $mnemonic
     * @return array
     * @throws Exception
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $key = $this->getKey($this->getSeed($mnemonic));

        foreach($this->patches as $bip => $patches) {
            foreach($patches as $patch) {
                if(!$this->isEnabledPatch($bip.'|'.$patch)) {
                    continue;
                }

                switch($bip) {
                    case 49:
                        $script = (new P2shScript(
                            ScriptFactory::scriptPubKey()->p2wkh(
                                (new HierarchicalKeyFactory)->fromExtended(
                                    $key->derivePath("49'/2'/0'")->toExtendedPublicKey()
                                )->derivePath($patch)->getPublicKey()->getPubKeyHash()
                            )
                        ))->getOutputScript();

                        $addresses["49'/2'/0'/{$patch}"] = (new AddressCreator)->fromOutputScript($script)->getAddress(new LitecoinNetwork);
                        break;
                    case 84:
                        $addresses[$patch] = (new SegwitAddress(
                            WitnessProgram::v0(
                                $key->derivePath($patch)->getPublicKey()->getPubKeyHash()
                            )
                        ))->getAddress(new LitecoinNetwork);
                        break;
                    default:
                        $addresses[$patch] = (new PayToPubKeyHashAddress(
                            $key->derivePath($patch)->getPublicKey()->getPubKeyHash()
                        ))->getAddress(new LitecoinNetwork);
                }
            }
        }

        return $addresses;
    }

    /**
     * @param array $addresses
     * @return array
     */
    public function getResult(array $addresses): array
    {
        $soChain = new SoChain;
        $rate = $soChain->getExchangeRate('LTC');

        return array_map(
            static fn(int|float $balance): int => $balance > 0 ? (int) round($balance * $rate, mode: PHP_ROUND_HALF_EVEN) : 0,
            $soChain->getBalances('LTC', $addresses)
        );
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://sochain.com/address/LTC/{$address}";
    }
}
