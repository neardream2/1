<?php

namespace App\Support\Currency;

use App\Support\JsServer;
use App\Support\Proxy;
use App\Support\Services\CoinCodex;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\Pool;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Class Solana
 */
class Solana extends Currency
{
    protected string $slug = 'solana';

    protected array $patches = [
        "44'/501'/0'/0'", "44'/501'/0'/1'", "44'/501'/0'/2'", "44'/501'/0'/3'", "44'/501'/0'/4'",
        "44'/501'", "44'/501'/0'", "44'/501'/1'", "44'/501'/2'", "44'/501'/3'", "44'/501'/4'",
    ];

    protected string $balanceEndPoint = 'https://api.mainnet-beta.solana.com';

    /**
     * @param string $mnemonic
     * @return array
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $jsServer = new JsServer;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            try {
                $addresses[$patch] = $jsServer->getSolanaAddress($mnemonic, $patch);
            }
            catch(Exception) {
                // nothing
            }
        }

        return array_filter($addresses, 'is_not_null');
    }

    public function getResult(array $addresses): array
    {
        $result = [];
        $rate = (new CoinCodex)->getLastPriceInUsd('SOL');

        $responses = Http::pool(function(Pool $pool) use ($addresses): void {
            foreach($addresses as $address) {
                $proxy = (new Proxy)->pluckForService('solana');

                $pool
                    ->as($address)
                    ->asJson()
                    ->withOptions(compact('proxy'))
                    ->post($this->balanceEndPoint, [
                        'jsonrpc' => '2.0',
                        'id' => Carbon::now()->getTimestampMs(),
                        'method' => 'getBalance',
                        'params' => [$address]
                    ]);
            }
        });

        foreach($responses as $address => $response) {
            if($response instanceof Exception) {
                Log::error("solana json rpc error: $address", ['message' => $response->getMessage()]);
                continue;
            }

            if(!$response->successful()) {
                Log::error("solana json rpc error: $address", ['response' => $response->body()]);
                continue;
            }

            $json = $response->json();
            $balance = $json['result']['value'] ?? 0;
            $result[$address] = $balance > 0 ? round(($balance / 1000000000) * $rate, 2, mode: PHP_ROUND_HALF_EVEN) : 0;
        }

        return $result;
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://explorer.solana.com/address/{$address}";
    }
}
