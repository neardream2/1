<?php

namespace App\Support\Currency;

use App\Support\Exceptions\WalletNotFoundException;
use App\Support\Services\SoChain;
use BitWasp\Bitcoin\Address\PayToPubKeyHashAddress;
use BitWasp\Bitcoin\Network\Networks\Dogecoin as DogecoinNetwork;
use Exception;

/**
 * Class Dogecoin
 */
class Dogecoin extends Currency
{
    protected string $slug = 'doge';

    protected array $patches = [
        "44'/3'/0'/0/0", "44'/3'/0'/0/1", "44'/3'/0'/0/2", "44'/3'/0'/0/3", "44'/3'/0'/0/4", "44'/3'/0'/0/5", "44'/3'/0'/0/6", "44'/3'/0'/0/7", "44'/3'/0'/0/8", "44'/3'/0'/0/9"
    ];

    /**
     * @param string $mnemonic
     * @return array
     * @throws Exception
     */
    public function getAddresses(string $mnemonic): array
    {
        $key = $this->getKey($this->getSeed($mnemonic));
        $addresses = [];

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            $addresses[$patch] = (new PayToPubKeyHashAddress(
                $key->derivePath($patch)->getPublicKey()->getPubKeyHash()
            ))->getAddress(new DogecoinNetwork);
        }

        return $addresses;
    }

    public function getResult(array $addresses): array
    {
        $result = [];
        $soChain = new SoChain;
        $rate = $soChain->getExchangeRate('DOGE');

        foreach($addresses as $address) {
            try {
                $balance = $soChain->getBalance('DOGE', $address);
                $result[$address] = $balance > 0 ? (int) round($balance * $rate, mode: PHP_ROUND_HALF_EVEN) : 0;
            }
            catch(WalletNotFoundException) {
                // nothing
            }
        }

        return $result;
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://sochain.com/address/DOGE/{$address}";
    }
}
