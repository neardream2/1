<?php

namespace App\Support\Currency;

use App\Support\JsServer;
use App\Support\Proxy;
use App\Support\Services\CoinCodex;
use Exception;
use Illuminate\Http\Client\Pool;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Class Tron
 */
class Tron extends Currency
{
    protected string $slug = 'tron';

    protected array $patches = [
        "44'/195'/0'/0/0", "44'/195'/0'/0/1", "44'/195'/0'/0/2", "44'/195'/0'/0/3", "44'/195'/0'/0/4",
    ];

    /**
     * @param string $mnemonic
     * @return array
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $jsServer = new JsServer;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            try {
                $addresses[$patch] = $jsServer->getTronAddress($mnemonic, $patch);
            }
            catch(Exception) {
                // nothing
            }
        }

        return array_filter($addresses, 'is_not_null');
    }

    /**
     * @param array $addresses
     * @return array
     */
    public function getResult(array $addresses): array
    {
        $result = [];
        $rate = (new CoinCodex)->getLastPriceInUsd('TRX');

        $responses = Http::pool(function(Pool $pool) use ($addresses): void {
            foreach($addresses as $address) {
                $proxy = (new Proxy)->pluckForService('solana');

                $pool
                    ->as($address)
                    ->asJson()
                    ->withOptions(compact('proxy'))
                    ->get('https://apilist.tronscan.org/api/account', compact('address'));
            }
        });

        foreach($responses as $address => $response) {
            if($response instanceof Exception) {
                Log::error("tronscan error: $address", ['message' => $response->getMessage()]);
                continue;
            }

            if(!$response->successful()) {
                Log::error("tronscan error: $address", ['response' => $response->body()]);
                continue;
            }

            $balance = $response->json('balance');

            if(!$balance) {
                $result[$address] = 0;
                continue;
            }

            $result[$address] = $balance > 0 ? round(($balance / 1000000) * $rate, 2, PHP_ROUND_HALF_EVEN) : 0;
        }

        return $result;
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://tronscan.org/#/address/{$address}";
    }
}
