<?php

namespace App\Support\Currency;

use App\Support\Services\DeBank;
use App\Support\Exceptions\WalletNotFoundException;
use Exception;
use Web3p\EthereumUtil\Util;

/**
 * Class Ethereum
 */
class Ethereum extends Currency
{
    protected string $name = 'ETH-подобные';

    protected string $slug = 'eth';

    protected array $patches = [
        "44'/60'/0'/0", "44'/60'/0'/1", "44'/60'/0'/2", "44'/60'/0'/3", "44'/60'/0'/4", "44'/60'/0'/5", "44'/60'/0'/6", "44'/60'/0'/7", "44'/60'/0'/8", "44'/60'/0'/9",
        "44'/60'/0'/0/0", "44'/60'/0'/0/1", "44'/60'/0'/0/2", "44'/60'/0'/0/3", "44'/60'/0'/0/4", "44'/60'/0'/0/5", "44'/60'/0'/0/6", "44'/60'/0'/0/7", "44'/60'/0'/0/8", "44'/60'/0'/0/9"
    ];

    /**
     * @param string $mnemonic
     * @return array
     * @throws Exception
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $key = $this->getKey($this->getSeed($mnemonic));
        $util = new Util;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            $addresses[$patch] = $util->publicKeyToAddress(
                $util->privateKeyToPublicKey(
                    $key->derivePath($patch)->getPrivateKey()->getHex()
                )
            );
        }

        return $addresses;
    }

    /**
     * @param array $addresses
     * @return array
     */
    public function getResult(array $addresses): array
    {
        return (new DeBank)->getResults($addresses);
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://debank.com/profile/{$address}";
    }
}
