<?php

namespace App\Support;

use App\Models\User;
use App\Support\WordList\FrenchWordList;
use App\Support\WordList\ItalianWordList;
use App\Support\WordList\SpanishWordList;
use BitWasp\Bitcoin\Mnemonic\Bip39\Wordlist\EnglishWordList;
use BitWasp\Bitcoin\Mnemonic\Bip39\Wordlist\JapaneseWordList;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Str;

/**
 * Class Mnemonic
 */
class Mnemonic
{
    protected string $mnemonic;

    protected CurrencyBuilder $currencyBuilder;

    protected static array $wordLists = [
        'en' => EnglishWordList::class,
        'ja' => JapaneseWordList::class,
        'es' => SpanishWordList::class,
        'fr' => FrenchWordList::class,
        'it' => ItalianWordList::class,
    ];

    /**
     * @param string $mnemonic
     */
    public function __construct(string $mnemonic)
    {
        $this->mnemonic = Str::of($mnemonic)->trim()->lower();
        $this->currencyBuilder = App::make(CurrencyBuilder::class);
    }

    public function getAllAddresses(): array
    {
        $addresses = [];

        foreach($this->currencyBuilder->all() as $currency) {
            if($currency->isEnabled()) {
                $addresses[$currency->getSlug()] = $currency->getAddresses($this->mnemonic);
            }
        }

        return $addresses;
    }

    /**
     * @return string
     */
    public function getMnemonic(): string
    {
        return $this->mnemonic;
    }

    public function getDifferences(string $locale): array
    {
        $differences = [];
        $wordList = $this->getWords($locale);
        //$words = explode("\t", $this->mnemonic);
        $words = mb_split('[[:space:]]', $this->mnemonic);

        foreach($words as $word) {
            if(!in_array($word, $wordList)) {
                $differences[] = $word;
            }
        }

        return $differences;
    }

    /**
     * @param User $user
     * @return bool
     */
    public function isUnique(User $user): bool
    {
        return !$user->wallets()->where('mnemonic', $this->mnemonic)->exists();
    }

    /**
     * @param string $locale
     * @return array
     */
    public function getWords(string $locale): array
    {
        return (new static::$wordLists[$locale])->getWords();
    }

    /**
     * @return array
     */
    public static function locales(): array
    {
        return array_keys(self::$wordLists);
    }
}
