<?php

namespace App\Support;

/**
 * Class DeBank
 * @deprecated Перенесен в App\Support\Services
 */
class DeBank extends \App\Support\Services\DeBank {}
