<?php

namespace App\Support;

use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Psr\SimpleCache\InvalidArgumentException;

/**
 * Class JsServer
 */
class JsServer
{
    protected string $host = 'http://node:3000/';

    /**
     * @param string $mnemonic
     * @param string $patch
     * @return ?string
     * @throws RequestException
     */
    public function getSolanaAddress(string $mnemonic, string $patch): ?string
    {
        return Http::get($this->host.'address-solana', compact('mnemonic', 'patch'))->throw()->json('address');
    }

    /**
     * @param string $mnemonic
     * @param string $patch
     * @return ?string
     * @throws RequestException
     */
    public function getTronAddress(string $mnemonic, string $patch): ?string
    {
        return Http::get($this->host.'address-tron', compact('mnemonic', 'patch'))->throw()->json('address');
    }

    /**
     * @return bool
     * @throws InvalidArgumentException
     */
    public function isAvailable(): bool
    {
        if(Cache::has('js_network_available')) {
            return true;
        }

        try {
            Http::get($this->host.'ping')->throw();
            Cache::set('js_network_available', 1, Carbon::now()->addMinutes(5));

            return true;
        }
        catch(Exception) {
            return false;
        }
    }
}
