<?php

namespace App\Support;

use App\Models\Proxy as Model;
use App\Support\Currency\Currency;
use Exception;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Class Proxy
 */
class Proxy
{
    public const TEST_TIMEOUT = 5;

    protected array $testSites = [
        'https://google.com', 'https://yandex.ru', 'https://ru.wikipedia.org'
    ];

    private string $regexp = '/^(socks5|http):\/\/(\w+):(\w+)@(((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)):(\w+)$/ui';

    /**
     * @return Collection
     */
    public function all(): Collection
    {
        return Cache::rememberForever(
            'proxy_list', static function(): Collection {
                return Model::where('is_active', 1)->get();
            }
        );
    }

    /**
     * @return string|null
     */
    public function pluck(): ?string
    {
        $all = $this->all();

        if($all->isEmpty()) {
            return null;
        }

        if($all->count() === 1) {
            return $all->first()->toConnectionString();
        }

        $latestKey = $this->getLatestKey();
        $current = $latestKey !== null ? ($all->firstWhere('id', '>', $latestKey) ?? $all->first()) : $all->first();

        $this->setLatestKey($current->id);

        return $current->toConnectionString();
    }

    /**
     * @param string $service
     * @return string|null
     */
    public function pluckForService(string $service): ?string
    {
        $all = $this->all();

        if($all->isEmpty()) {
            return null;
        }

        if($all->count() === 1) {
            return $all->first()->toConnectionString();
        }

        $latestKey = Cache::get('proxy_latest_key_'.$service) ?? null;
        $current = $latestKey !== null ? ($all->firstWhere('id', '>', $latestKey) ?? $all->first()) : $all->first();
        Cache::forever('proxy_latest_key_'.$service, $current->id);

        return $current->toConnectionString();
    }

    /**
     * @param string $proxy
     * @return bool
     */
    public function valid(string $proxy): bool
    {
        if(!preg_match($this->regexp, $proxy)) {
            return false;
        }

        foreach($this->testSites as $site) {
            try {
                Http::withOptions([
                    'proxy' => $proxy,
                    'timeout' => self::TEST_TIMEOUT
                ])->head($site);

                return true;
            }
            catch(Exception) {
                // nothing
            }
        }

        return false;
    }

    public function stringToArray(string $proxy): array
    {
        preg_match($this->regexp, $proxy, $matches);

        return [
            'protocol' => $matches[1],
            'ip' => $matches[4],
            'port' => $matches[8],
            'user' => $matches[2],
            'password' => $matches[3]
        ];
    }

    /**
     * @return void
     */
    public function reset(): void
    {
        foreach(['proxy_list', 'proxy_latest_key'] as $key) {
            Cache::forget($key);
        }

        Cache::tags('proxy_latest_key_for_task')->clear();
    }

    /**
     * @return int|null
     */
    protected function getLatestKey(): ?int
    {
        return Cache::get('proxy_latest_key') ?? null;
    }

    /**
     * @param int $key
     */
    protected function setLatestKey(int $key): void
    {
        Cache::forever('proxy_latest_key', $key);
    }
}
