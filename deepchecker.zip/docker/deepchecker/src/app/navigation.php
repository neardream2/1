<?php

use App\Models\Wallet;
use Illuminate\Http\Request;

return [
    [
        'name' => [
            'Дашборд',
            static fn(Request $request): int => $request->user()->is_admin ? Wallet::count() : $request->user()->wallets()->count()
        ],
        'route' => 'index',
        'icon' => 'fas fa-wallet',
        'aliases' => ['wallets.edit', 'mnemonics.invalid']
    ],

    [
        'name' => 'Пользователи',
        'route' => 'users.index',
        'icon' => 'fas fa-users',
        'aliases' => ['users.create', 'users.edit'],
        'gate' => 'view-any'
    ],

    [
        'name' => 'Прокси',
        'route' => 'proxies.index',
        'icon' => 'fas fa-network-wired',
        'aliases' => ['proxies.create', 'proxies.edit'],
        'gate' => 'view-any'
    ],

    [
        'name' => 'Настройки',
        'route' => 'settings.show',
        'icon' => 'fas fa-cogs'
    ],

    [
        'name' => 'Поддержка',
        'route' => 'support',
        'icon' => 'fas fa-life-ring',
        'gate' => 'view-any'
    ],

    [
        'name' => 'Закончить сеанс',
        'route' => 'logout',
        'icon' => 'fas fa-sign-out-alt'
    ]
];
